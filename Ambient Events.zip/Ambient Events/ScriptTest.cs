﻿using GTA;
using GTA.Math;
using GTA.Native;
using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Xml;
using Lively_World;
using System.IO;

enum EmergencyType
{
    FIRETRUCK = 0,// 0
    AMBULANCE,
    POLICE,

};

enum WeatherType
{
    EXTRA_SUNNY = -1750463879,
    CLEAR = 916995460,
    NEUTRAL = -1530260698,
    SMOG = 282916021,
    FOGGY = -1368164796,
    OVERCAST = -1148613331,
    CLOUDS = 821931868,
    CLEARING = 1840358669,
    RAIN = 1420204096,
    THUNDER = -1233681761,
    SNOW = -273223690,
    BLIZZARD = 669657108,
    LIGHT_SNOW = 603685163,
    X_MAS = -1429616491
};

public enum EventType
{
    DriverRushing, //Moving
    Carjacker, //Static
    Taxi, //Moving
    EmergencyRushing, //Moving
    Tow, //Moving
    Racer, Bennys, //Moving
    Deal, //Static
    Hunter,AnimalTrophy, //Static
    GangDriveby, //Moving
    VehicleInteraction, //Moving
    ImprovedFreight, //HandleFreight

};

public class LivelyWorld : Script
{
    public string ScriptName = "Lively World";
    string ScriptVer = "0.4";

    public static bool DebugOutput = false;

    public static bool Debug = false;
    public static bool DebugBlips = false;

    public static int ReplacerTime = 0;
    public static int VehMonitorTime;
    public static int BlackistedEventsTime;
    int SmallEventCooldownTime = Game.GameTime+10000;
    int SpawnerEventCooldownTime = Game.GameTime+20000;
    int Interval = 1000;
    public static List<Vector3> AmbientHeliLanding = new List<Vector3>
    {
        new Vector3 (-144,-593,211),
    };
    public static List<EventType> BlacklistedEvents = new List<EventType>();
    public static List<VehicleHash> HuntingTrucks = new List<VehicleHash>
        {
            VehicleHash.Picador,VehicleHash.Dubsta3,VehicleHash.Bison,VehicleHash.Rebel, VehicleHash.Rebel2,VehicleHash.Sadler,VehicleHash.BobcatXL,VehicleHash.Sandking,VehicleHash.Sandking2
        };
    public static int BlackistedImportantEventsTime;
    public static int BlackistedImportantEventsCooldown;

    //static public  List<EventType> BlacklistedImportantEvents = new List<EventType>();

    //int FirstEventCooldown = Game.GameTime+RandomInt(1,4);


    public static List<EventType> DisabledEvents = new List<EventType>();


    Vector3 NoEventsHere = Vector3.Zero;
    Vector3 NoEventsHereFar = Vector3.Zero;
    

    int BlacklistCooldown = Game.GameTime; //30 secs

    //Settings
    bool VehicleReplacer = true;
    bool TrafficInjector = true;

    bool TruckRespray = true;


    float InteractionRange = 100f;
    float SpawnerRange = 100f;

    int CriminalEventProb = 10;
    int AccidentEventProb = 30;



    public static int CriminalRelGroup = World.AddRelationshipGroup("CriminalRelGroup");
    public static int NeutralRLGroup = World.AddRelationshipGroup("LWNEUTRAL");
    public static int BallasRLGroup = World.AddRelationshipGroup("lwballas");
    public static int EventFrecuency = 100;
    public static int EventCooldown = 60000;

    public Vector3 CityCenter = new Vector3(-53, -878, 40);
    public Vector3 BennysMotorworks = new Vector3(-184, -1297, 30);

    public static List<Model> DrugCars = new List<Model> { "blista", "blista2", "moonbeam", "glendale", "dukes", "cavalcade", "rhapsody", "blade", "faction2","retinue", "picador", "emperor","voodoo","regina" };

    public static List<Model> Respraymodels = new List<Model> { "mule", "mule2", "benson", "packer", "hauler", "pounder", "phantom", "roadkiller" };
    public static List<string> BlacklistedAreas = new List<string> { "golf", "armyb", "jail", "airp" };


    public static List<Replacer> ReplacersList = new List<Replacer>();
    public static List<TrafficSpawner> TrafficSpawnerList = new List<TrafficSpawner>();

    public static List<TaxiEvent> Taxis = new List<TaxiEvent>();
    public static List<DrugDeal> DrugDeals = new List<DrugDeal>();
    public static List<Hunter> Hunters = new List<Hunter>();
    public static List<Entity> TemporalPersistence = new List<Entity>();

    public static List<Vehicle> AllVehicles = new List<Vehicle>();
    public static List<Vehicle> MonitoredVehicles = new List<Vehicle>();
    public static List<Ped> AllPeds = new List<Ped>();
    public static List<Model> MonitoredModels = new List<Model>();


    public static List<Model> LostModels = new List<Model> {"G_M_Y_Lost_01",
"G_M_Y_Lost_02",
"G_M_Y_Lost_03",
"G_F_Y_Lost_01" };
    public static List<Model> BallasModels = new List<Model>
    {
        "G_F_Y_Ballas_01","G_M_Y_BallaEast_01","G_M_Y_BallaOrig_01","G_M_Y_BallaSout_01"
    };
    public static List<Model> FamiliesModels = new List<Model>
    {
        "A_M_M_OG_Boss_01","G_F_Y_Families_01","G_M_Y_FamCA_01","G_M_Y_FamDNF_01","G_M_Y_FamFOR_01"
    };
    public static List<Model> VagosModels = new List<Model>
    {
        "A_M_Y_MexThug_01","G_M_Y_MexGoon_01","G_M_Y_MexGoon_02","G_M_Y_MexGoon_03","G_F_Y_Vagos_01","mp_m_g_vagfun_01"
    };

    public static List<Vehicle> BlacklistedVehicles = new List<Vehicle>();
    public static List<Model> BlacklistedModels = new List<Model>();

    public List<Model> NormalVehicleModel = new List<Model>
    {
    "baller",
    "baller2",
    "blista",
    "cavalcade2",
    "daemon",
    "dubsta",
    "f620",
    "felon",
    "fugitive",
    };
    public static List<Model> BobCatSecurity = new List<Model>
    {
        "bsgranger","bsfugitive","bspony"
    };
    public static List<Vector3> OceanSpawns = new List<Vector3> {

        new Vector3 (-2488,-1778,0),
 new Vector3(-3164,-483,3),
 new Vector3(-4168,1818,1),
 new Vector3(-3968,3693,0),
 new Vector3(-2272,6191,2),
 new Vector3(-1041,7789,0),
 new Vector3(1605,7623,2),
 new Vector3(3721,7004,1),
 new Vector3(4548,5168,0),
 new Vector3(4779,2655,1),
 new Vector3(4671,-255,0),
 new Vector3(3587,-3036,0),
 new Vector3(1935,-4183,2),
 new Vector3(-1539,-4879,2),
 new Vector3(-3880,-2390,1),
};
    public List<Model> Bennys = new List<Model>
    {

    };

    /*
        "comet",
    "vacca2",
    "dominator3",
    "elegy",
    "elegy4",
    "minivan2",
    "faction3",
        "faction2",
    "banshee2",
    "sultanrs",
    "specter2",
        */
    public List<Model> Racecars = new List<Model>
    {

    };

    public static float AngleBetweenVectors(Vector3 vec, Vector3 vec2)
    {
        Vector3 h = vec - vec2;
        return h.ToHeading();
        //return Function.Call<float>(Hash.GET_ANGLE_BETWEEN_2D_VECTORS, vec.X, vec.Y, vec2.X, vec2.Y);
    }
    public static List<Model> RacerModel = new List<Model>
        {
        "a_m_m_eastsa_01","a_m_m_eastsa_02","a_m_m_malibu_01","a_m_m_mexcntry_01","a_m_m_mexlabor_01","a_m_m_og_boss_01","a_m_m_polynesian_01","a_m_m_soucent_01","a_m_m_soucent_03",
        "a_m_m_soucent_04","a_m_m_stlat_02","s_m_m_bouncer_01","s_m_m_lifeinvad_01","u_m_m_aldinapoli","u_m_m_bikehire_01","u_m_m_filmdirector","u_m_m_rivalpap","u_m_m_willyfist",
        "u_m_y_baygor","u_m_y_chip","u_m_y_cyclist_01","u_m_y_fibmugger_01","u_m_y_guido_01","u_m_y_gunvend_01","u_m_y_hippie_01","u_m_y_paparazzi","u_m_y_party_01","u_m_y_sbike",
        "u_m_y_tattoo_01",
    };
    public LivelyWorld()
    {
        Tick += OnTick;
        KeyDown += OnKeyDown;
        KeyUp += OnKeyUp;
        LoadSettings();
        World.SetRelationshipBetweenGroups(Relationship.Hate, CriminalRelGroup, Function.Call<int>(GTA.Native.Hash.GET_HASH_KEY, "COP"));
        World.SetRelationshipBetweenGroups(Relationship.Hate, Function.Call<int>(GTA.Native.Hash.GET_HASH_KEY, "COP"), CriminalRelGroup);
        NoEventsHereFar = Game.Player.Character.Position;
        NoEventsHere = Game.Player.Character.Position;


        File.WriteAllText(@"scripts\LivelyWorldDebug.txt", "Script started -" + DateTime.Now + "-GameVer " + Game.Version.ToString());

        if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now +" - Debug output is ON"); else File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Debug output is OFF");

    }
    public static bool AnyVehicleNear(Vector3 pos, float radius)
    {
        return Function.Call<bool>(Hash.IS_ANY_VEHICLE_NEAR_POINT, pos.X,pos.Y, pos.Z, radius);
    }
    void SpawnAnimalTrophy()
    {
        if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n"+DateTime.Now +" - SpawnAnimalTrophy()");
        
        foreach (Vehicle veh in AllVehicles)
        {
            if (CanWeUse(veh) && !WouldPlayerNoticeChangesHere(veh.Position) && 
                veh.IsStopped &&veh.IsInRangeOf(Game.Player.Character.Position, 90f) && 
                !BlacklistedVehicles.Contains(veh) && HuntingTrucks.Contains((VehicleHash)veh.Model.Hash))
            {
                if ((VehicleHash)veh.Model.Hash == VehicleHash.BobcatXL && veh.IsExtraOn(1)) continue;

                if ((VehicleHash)veh.Model.Hash == VehicleHash.Sadler && (veh.IsExtraOn(6) || veh.IsExtraOn(7))) continue;
                if ((VehicleHash)veh.Model.Hash == VehicleHash.Sandking2 && veh.GetMod(VehicleMod.Roof)==4) continue;

                 if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", " - Found "+veh.DisplayName);

                if (veh.Speed > 2f) veh.FreezePosition=true;
                Function.Call(GTA.Native.Hash._0x0DC7CABAB1E9B67E, veh, true);
                veh.IsPersistent = true;
                Vector3 pos = veh.Position + (veh.UpVector * 1) + (veh.ForwardVector * -2);

                if (RandomInt(0, 10) <= 5)
                {
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", " - Spawning rabbits");

                    for (int i = 0; i < 5; i++)
                    {
                        Ped ped = World.CreatePed(PedHash.Rabbit, pos, veh.Heading);
                        Function.Call(Hash._0x0DC7CABAB1E9B67E, ped, true);
                        Script.Wait(100);
                        ped.Velocity = veh.Velocity;
                        Function.Call(Hash.SET_PED_TO_RAGDOLL, ped, 2000, 2000, 3, true, true, false);
                        Function.Call(Hash.CREATE_NM_MESSAGE, 1151);
                        Function.Call(Hash.GIVE_PED_NM_MESSAGE, ped, true);
                        ped.ApplyDamage(900);
                        //ped.AttachTo(veh, 0);

                        TemporalPersistence.Add(ped);//ped.IsPersistent = false;
                    }
                }
                else
                {
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", " - Spawning deer");

                    Ped ped = World.CreatePed(PedHash.Deer, pos, veh.Heading);
                    Function.Call(GTA.Native.Hash._0x0DC7CABAB1E9B67E, ped, true);
                    Script.Wait(100);
                    ped.Velocity = veh.Velocity;
                    Function.Call(Hash.SET_PED_TO_RAGDOLL, ped, 2000, 2000, 3, true, true, false);
                    Function.Call(Hash.CREATE_NM_MESSAGE, 1151);
                    Function.Call(Hash.GIVE_PED_NM_MESSAGE, ped, true);
                    ped.ApplyDamage(900);
                    //ped.AttachTo(veh, 0);

                    TemporalPersistence.Add(ped);//ped.IsPersistent = false;
                }

                if (DebugBlips)
                {
                    if (!veh.CurrentBlip.Exists())
                    {
                        veh.AddBlip();
                        veh.CurrentBlip.Sprite = BlipSprite.Hunting;
                        veh.CurrentBlip.Color = BlipColor.Yellow;
                        veh.CurrentBlip.IsShortRange = true;
                    }
                }
                if (Debug)
                {
                    UI.Notify("~b~Spawned trophy on " +veh.FriendlyName);
                }


                if (!CanWeUse(veh.Driver) && RandomInt(0, 10) <= 5) //
                {
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", " - Spawning Hunter nearby");

                    Ped hunter = World.CreatePed(PedHash.Hunter, World.GetSafeCoordForPed(veh.Position.Around(2),false), RandomInt(0, 350));
                    Function.Call(Hash.TASK_START_SCENARIO_IN_PLACE, hunter, "WORLD_HUMAN_SMOKING", 5000, true);
                    //hunter.IsPersistent = false;
                    
                    TemporalPersistence.Add(hunter);
                }
                TemporalPersistence.Add(veh);

                BlacklistedVehicles.Add(veh);
                Script.Wait(1000);
                if(veh.FreezePosition) veh.FreezePosition = false;
                //BlacklistedImportantEvents.Add(EventType.AnimalTrophy);
                 if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", " - Finished");
                AnimalTrophyCooldown = Game.GameTime + (1000 * 60 * 10);
                break;
            }
        }
    }
    public static Vector3 LerpByDistance(Vector3 A, Vector3 B, float x)
    {
        Vector3 P = x * Vector3.Normalize(B - A) + A;
        return P;
    }

    void SpawnCarInteraction(Vehicle v, Ped p)
    {
        Vehicle veh = v;

        /*
        foreach (Vehicle v1 in AllVehicles)
        {
            if (CanWeUse(v1) && v1.IsInRangeOf(Game.Player.Character.Position, InteractionRange) && !WouldPlayerNoticeChangesHere(v1.Position) && !v1.IsPersistent && v1.Model.IsCar && !CanWeUse(v1.Driver) && v1.IsStopped && !v1.EngineRunning && v1.HeightAboveGround > 0.4f)
            {
                veh = v1;
                break;
            }
        }*/
        if (CanWeUse(veh))
        {
            Ped ped = p;// World.CreateRandomPed(veh.Position.Around(5));
            TemporalPersistence.Add(ped);
            TemporalPersistence.Add(veh);

            //ped.SetNoCollision(veh, true);
            //veh.SetNoCollision(ped, true);

            if (CanWeUse(veh) && CanWeUse(ped))
            {
                int scenarioint = RandomInt(0, 3);


                TaskSequence seq = new TaskSequence();


                switch (scenarioint)
                {
                    case 0:
                        {
                            //veh.EngineHealth = 200;
                            //veh.OpenDoor(VehicleDoor.Hood, false, false);
                            veh.OpenDoor(VehicleDoor.FrontLeftDoor, true, true);
                            Vector3 pos = veh.Position + (veh.ForwardVector * (veh.Model.GetDimensions().Y * 0.54f));
                            float heading = veh.Heading;
                            ped.Heading = veh.Heading;
                            ped.Position = pos;
                            Function.Call(Hash.TASK_START_SCENARIO_IN_PLACE, 0, "WORLD_HUMAN_VEHICLE_MECHANIC", 20000, true);
                            break;
                        }
                    case 1:
                        {
                            Vector3 pos = veh.Position + (veh.ForwardVector * -0.5f) + veh.RightVector * (veh.Model.GetDimensions().X * 0.6f);
                            ped.Heading = veh.Heading-90;
                            ped.Position = pos;
                            Function.Call(Hash.TASK_START_SCENARIO_IN_PLACE, 0, "WORLD_HUMAN_LEANING", 20000, true);
                            break;
                        }
                    case 2:
                        {
                            Vector3 pos = veh.Position + (veh.ForwardVector * -0.5f) + veh.RightVector * (veh.Model.GetDimensions().X * 0.7f);
                            ped.Heading = veh.Heading+90;
                            ped.Position = pos;
                            Function.Call(Hash.TASK_START_SCENARIO_IN_PLACE, 0, "WORLD_HUMAN_MAID_CLEAN", 20000, true);
                            break;
                        }
                }
                Function.Call(Hash.TASK_ENTER_VEHICLE, 0, veh, 20000, -1, 1f, 1, 0);
                Function.Call(Hash.TASK_PAUSE, 0, RandomInt(2, 4) * 1000);
                Function.Call(Hash.TASK_VEHICLE_DRIVE_WANDER, 0, veh, 30f, 1 + 2 + 4 + 8 + 16 + 32);
                seq.Close();
                ped.Task.PerformSequence(seq);
                seq.Dispose();
                ped.BlockPermanentEvents = false;

                //Function.Call(Hash.TASK_START_SCENARIO_AT_POSITION, ped, "WORLD_HUMAN_VEHICLE_MECHANIC", pos.X, pos.Y, pos.Z, heading, 50000, false, false);

                if (DebugBlips && CanWeUse(ped))
                {
                    ped.AddBlip();
                    ped.CurrentBlip.Color = BlipColor.Green;
                    ped.CurrentBlip.Scale = 0.7f;
                    ped.CurrentBlip.IsShortRange = true;
                    ped.CurrentBlip.Name = "Car interaction";
                }
            }
        }
    }

    int FreightTruckCooldown = Game.GameTime + 5000;
    void HandleFreightTrucks()
    {
        if (DisabledEvents.Contains(EventType.ImprovedFreight)) return;
        if (IsInNamedArea(Game.Player.Character, "Senora Fwy") || IsInNamedArea(Game.Player.Character, "Great Ocean Hwy"))//
        {
            foreach (Vehicle veh in AllVehicles)
            {
                if (CanWeUse(veh) && !Game.Player.Character.IsInRangeOf(veh.Position, 20f) && !veh.IsPersistent && CanWeUse(veh.Driver) && veh.Speed > 3f && !veh.IsOnScreen && (veh.Model == "juggernaut" || veh.Model == "packer" || veh.Model == "hauler" || veh.Model == "phantom" || veh.Model == "roadkiller"))
                {
                    Vehicle trailer = GetTrailer(veh);

                    if (!CanWeUse(trailer) && !Function.Call<bool>(Hash.IS_VEHICLE_ATTACHED_TO_TRAILER, veh))
                    {

                        veh.IsPersistent = true;
                        Script.Wait(200);
                        Vector3 pos = veh.Position + (veh.ForwardVector * -10);
                        TemporalPersistence.Add(veh);

                        trailer = World.CreateVehicle(VehicleHash.FreightTrailer, pos, veh.Heading);
                        trailer.Speed = veh.Speed;
                        TemporalPersistence.Add(trailer);

                        if (DebugBlips)
                        {
                            if (!veh.CurrentBlip.Exists())
                            {
                                veh.AddBlip();
                                veh.CurrentBlip.Color = BlipColor.White;
                                veh.CurrentBlip.Sprite = BlipSprite.PersonalVehicleCar;
                                veh.CurrentBlip.IsShortRange = false;
                                veh.CurrentBlip.Name = "Freight Truck";
                            }
                            if (!veh.CurrentBlip.Exists())
                            {
                                trailer.CurrentBlip.Color = BlipColor.White;
                                trailer.CurrentBlip.Sprite = BlipSprite.PersonalVehicleCar;
                                trailer.CurrentBlip.IsShortRange = false;
                                trailer.CurrentBlip.Name = "Freight trailer";
                            }
                        }


                        if (RandomInt(0, 10) <= 5)
                        {
                            Vehicle cargo = World.CreateVehicle(VehicleHash.Annihilator, pos + new Vector3(0, 3, 5), veh.Heading);
                            TemporalPersistence.Add(cargo);
                            cargo.ToggleExtra(1, false);
                            cargo.AttachTo(trailer, 0, (new Vector3(0, 2, -0.4f)), new Vector3(0, 0, 0));
                            if (Debug) UI.Notify("[FreighTrucks] Freight (annihilator) spawned on a " + veh.FriendlyName + ".");

                        }
                        else
                        {
                            Vehicle cargo = World.CreateVehicle(VehicleHash.Buzzard2, pos + new Vector3(0, 3, 5), veh.Heading);
                            TemporalPersistence.Add(cargo);
                            cargo.ToggleExtra(1, false);
                            cargo.AttachTo(trailer, 0, (new Vector3(0, -5, -0.3f)), new Vector3(0, 0, 0));

                            cargo = World.CreateVehicle(VehicleHash.Buzzard2, pos + new Vector3(0, 3, 5), veh.Heading);
                            TemporalPersistence.Add(cargo);
                            cargo.ToggleExtra(1, false);
                            cargo.AttachTo(trailer, 0, (new Vector3(0, 5, -0.3f)), new Vector3(0, 0, 0));
                            if (Debug) UI.Notify("[FreighTrucks] Freight (helis) spawned on a " + veh.FriendlyName + ".");

                        }

                        Function.Call(Hash.ATTACH_VEHICLE_TO_TRAILER, veh, trailer, 10);
                        FreightTruckCooldown = Game.GameTime + (1000 * 60 * RandomInt(2,6));
                        BlacklistedVehicles.Add(veh);
                        break;
                    }
                }
                /*
                if((VehicleHash)veh.Model.Hash == VehicleHash.FreightTrailer)
                {
                    foreach (Vehicle v in AllVehicles) if (v.Model.IsHelicopter && v.IsInRangeOf(veh.Position, 50f)) v.AttachTo(veh, 0, (new Vector3(0, 0, -0.4f)), new Vector3(0,0,0));
                }*/
            }
        }
        else if(Debug) UI.Notify("[FreighTrucks] Player is not in Senora Freeway, on the desert area.");
    }



    int HandleFlabedsCooldown = Game.GameTime + 5000;
    void HandleFlabeds()
    {
        if (HandleFlabedsCooldown<Game.GameTime)//
        {
            foreach (Vehicle veh in AllVehicles)
            {
                if (CanWeUse(veh) && !BlacklistedVehicles.Contains(veh) && !veh.IsOnScreen && (veh.Model == "flatbed" &&!LastDriverIsPed(veh,Game.Player.Character)) && !Game.Player.Character.IsInRangeOf(veh.Position, 20f))
                {
                    Vehicle cargo = World.CreateVehicle(NormalVehicleModel[RandomInt(0,NormalVehicleModel.Count-1)], veh.Position + (veh.UpVector * 5f));
                    HandleFlabedsCooldown = Game.GameTime + (1000 *  RandomInt(2, 6));
                    BlacklistedVehicles.Add(veh);
                    cargo.IsPersistent = false;
                    
                    Vector3 relativePos = new Vector3(0, -2, 0.7f + (cargo.Model.GetDimensions().Z / 5)); //
                    cargo.AttachTo(veh, 0, relativePos, new Vector3(0, 0, 0));

                    if (!veh.CurrentBlip.Exists() && DebugBlips)
                    {
                        veh.AddBlip();
                        veh.CurrentBlip.Color = BlipColor.White;
                        veh.CurrentBlip.Name = "Flatbed";
                    }

                   if(Debug) UI.Notify("[FlatBeds] Attached "+ cargo.FriendlyName+" on " + veh.FriendlyName + ".");
                    break;
                }
                /*
                if((VehicleHash)veh.Model.Hash == VehicleHash.FreightTrailer)
                {
                    foreach (Vehicle v in AllVehicles) if (v.Model.IsHelicopter && v.IsInRangeOf(veh.Position, 50f)) v.AttachTo(veh, 0, (new Vector3(0, 0, -0.4f)), new Vector3(0,0,0));
                }*/
            }
        }
        else if (Debug) UI.Notify("[FlatBeds] On cooldown.");
    }
    void SmartAttach(Vehicle carrier, Vehicle veh)
    {
        Vector3 relativePos = new Vector3(0, -2, 0.7f + (veh.Model.GetDimensions().Z / 5)); //
        veh.AttachTo(carrier, 0, relativePos, new Vector3(0, 0, 0));
        veh.Detach();
        veh.Speed = carrier.Speed;

        Script.Wait(500);

        Vector3 hook = Function.Call<Vector3>(Hash.GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS, carrier, veh.Position.X, veh.Position.Y, veh.Position.Z);
        veh.AttachTo(carrier, 0, hook, new Vector3(0, 0, 0));
    }
    public static bool IsEntityAheadEntity(Entity e1, Entity e2)
    {
        Vector3 pos = e1.Position;
        return Function.Call<Vector3>(Hash.GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS, e2, pos.X, pos.Y, pos.Z).Y > 1;
    }
    public static Vector3 GetEntityOffset(Entity ent, float ahead, float right)
    {
        return ent.Position + (ent.ForwardVector * ahead) + (ent.RightVector * right);
    }

    public static void TemporalPullover(Ped p)
    {
        Vehicle veh = p.CurrentVehicle;
        Vector3 pos = GetEntityOffset(veh, 30, 0);
        Vector3 park = World.GetNextPositionOnStreet(GetEntityOffset(veh, 50, 0)) + (veh.RightVector * 10);

        TaskSequence seq = new TaskSequence();
        Function.Call(Hash.TASK_VEHICLE_DRIVE_TO_COORD_LONGRANGE, 0, veh, pos.X, pos.Y, pos.Z, 8f, 8, 2f);
        Function.Call(Hash.TASK_VEHICLE_DRIVE_TO_COORD_LONGRANGE, 0, veh, park.X, park.Y, park.Z, 3f, 4456509, 2f);

        Function.Call(Hash.TASK_PAUSE, 0, RandomInt(2, 4) * 1000);
        Function.Call(Hash.TASK_LEAVE_VEHICLE, 0, veh, 262144);
        Function.Call(Hash.TASK_PAUSE, 0, RandomInt(2, 4) * 1000);

        Function.Call(Hash.TASK_START_SCENARIO_IN_PLACE, 0, "WORLD_HUMAN_LEANING", 5000f, false);

        Function.Call(Hash.TASK_ENTER_VEHICLE, 0, veh, 20000, -1, 1f, 1, 0);
        Function.Call(Hash.TASK_VEHICLE_DRIVE_WANDER, 0, veh, 30f, 1 + 2 + 4 + 8 + 16 + 32);
        seq.Close();
        p.Task.PerformSequence(seq);
        seq.Dispose();

        p.BlockPermanentEvents = false;
    }

    List<Rope> TrailerRopes = new List<Rope>();

    void ProcessCheats()
    {
        //Vector3 GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS(Entity entity, float posX, float posY, float posZ) // 2274BC1C4885E333 6477EC9E

        /*
        if (Game.IsControlJustPressed(2,GTA.Control.Context))
        {
            Ped p = World.GetClosestPed(GetEntityOffset(Game.Player.Character, 20, 0),20f);
            if(CanWeUse(p) && CanWeUse(p.CurrentVehicle))
            {
                Vehicle veh = p.CurrentVehicle;
                Vector3 pos = GetEntityOffset(veh, 30, 0);
                Vector3 park = World.GetNextPositionOnStreet(GetEntityOffset(veh, 50, 0))+(veh.RightVector*10);

                TaskSequence seq = new TaskSequence();
                Function.Call(Hash.TASK_VEHICLE_DRIVE_TO_COORD_LONGRANGE, 0, veh, pos.X, pos.Y, pos.Z, 8f, 8, 2f);
                Function.Call(Hash.TASK_VEHICLE_DRIVE_TO_COORD_LONGRANGE, 0, veh, park.X, park.Y, park.Z, 3f, 4456509, 2f);

                Function.Call(Hash.TASK_PAUSE, 0, RandomInt(2, 4) * 1000);
                Function.Call(Hash.TASK_LEAVE_VEHICLE, 0, veh, 262144);
                Function.Call(Hash.TASK_PAUSE, 0, RandomInt(2, 4) * 1000);

                Function.Call(Hash.TASK_START_SCENARIO_IN_PLACE, 0, "WORLD_HUMAN_LEANING",5000f, false);

                Function.Call(Hash.TASK_ENTER_VEHICLE, 0, veh, 20000, -1, 1f, 1, 0);
                Function.Call(Hash.TASK_VEHICLE_DRIVE_WANDER, 0, veh, 30f, 1 + 2 + 4 + 8 + 16 + 32);
                seq.Close();
                p.Task.PerformSequence(seq);
                seq.Dispose();

                p.BlockPermanentEvents = false;
            }

        }
        */


        /* foreach (Rope r in TrailerRopes)
         {
             if (!Game.Player.Character.IsInRangeOf(r.GetVertexCoord(1), 200f)) { r.Delete(); break; }
         }*/
         
        if (1!=1)
        {
            Vehicle v = Game.Player.Character.CurrentVehicle;

            if (CanWeUse(v) &&Math.Abs(Function.Call<Vector3>(Hash.GET_ENTITY_SPEED_VECTOR, v, true).X) > 3f)
            {


    /*
    TASK_LEAVE_VEHICLE(Ped ped, Vehicle vehicle, int flags) // D3DBCE61A490BE02 7B1141C6
Flags from decompiled scripts:
0 = normal exit and closes door.
1 = normal exit and closes door.
16 = teleports outside, door kept closed.
64 = normal exit and closes door, maybe a bit slower animation than 0.
256 = normal exit but does not close the door.
4160 = ped is throwing himself out, even when the vehicle is still.
262144 = ped moves to passenger seat first, then exits normally
    */
    /*
    v.OpenDoor(VehicleDoor.FrontRightDoor, true, false);
                Script.Wait(300);
                Ped p = v.GetPedOnSeat(VehicleSeat.RightFront);
                //if (CanWeUse(p)) p.Kill();

                Function.Call(Hash.TASK_LEAVE_VEHICLE, p, v, 4160);

                //p.Position = v.Position+v.RightVector;
                Script.Wait(500);
                Function.Call(Hash.SET_PED_TO_RAGDOLL, p, 2000, 2000, 3, true, true, false);
                Function.Call(Hash.CREATE_NM_MESSAGE, 1151);
                Function.Call(Hash.GIVE_PED_NM_MESSAGE, p, true);
                UI.Notify("ragdolled");
                */
            }
        }
        if (WasCheatStringJustEntered("attach"))
        {
            Vehicle v = Game.Player.Character.CurrentVehicle;
            bool IsTrailer = false;
            bool CarrierIsNormalVehicle = false;
            Vehicle carrier = Game.Player.Character.CurrentVehicle;

            if (!CanWeUse(v) || !CanWeUse(carrier)) return;
            //foreach (Vehicle veh in World.GetNearbyVehicles(Game.Player.Character.Position, 20f)) if (veh != carrier && !veh.IsAttached()) v = veh;



            if (CanWeUse(v) && CanWeUse(carrier))
            {

                Vector3 back = -(carrier.ForwardVector * 30);
                RaycastResult ray = World.Raycast(carrier.Position, back, 30f, IntersectOptions.Everything, carrier);


                if(!ray.DitHitEntity) ray = World.Raycast(carrier.Position-carrier.UpVector, back, 30f, IntersectOptions.Everything, carrier);

                if (ray.DitHitEntity && ray.HitEntity.Model.IsVehicle)
                {
                    v = ray.HitEntity as Vehicle;
                    UI.Notify("Carrier: "+carrier.FriendlyName);

                    UI.Notify("Trailer: "+v.FriendlyName);

                }
                else
                {
                    UI.Notify("No vehicle found behind yours.");
                    return;
                }
                if (v.IsAttached()) v.Detach();
                if (carrier.IsAttached()) carrier.Detach();

                Vector3 offset = new Vector3(0, -1.4f, 3f + (v.Model.GetDimensions().Z * 0.35f));
                Vector3 truckoffset = new Vector3(0f, (v.Model.GetDimensions().Y / 2f), offset.Z * 0.4f);

                Vehicle trailer = GetTrailer(v);
                if (trailer == null)
                {
                    foreach (Vehicle t in World.GetNearbyVehicles(v.Position, 30f)) if (t.Model== "freighttrailer") trailer = t;
                }

                    if (trailer!= null)
                {
                    carrier = trailer;
                    IsTrailer = true;
                    UI.Notify("HasTrailer");
                }
                else
                {
                    UI.Notify("No Trailer");
                }

                float height = v.HeightAboveGround;
                if (IsTrailer)
                {                    
                    if (carrier.Model == "freighttrailer")
                    {
                        truckoffset = new Vector3(0f, (v.Model.GetDimensions().Y / 2f), 0f);
                        offset = new Vector3(0, -0f, 0f);
                    }
                }
                else
                {
                    if (carrier.Model == "mule4")
                    {
                        offset = new Vector3(0, -0.9f, height); //v.Model.GetDimensions().Z * 0.35f
                        truckoffset = new Vector3(0f, (v.Model.GetDimensions().Y / 2f), 0.1f);//offset.Z * 0.4f);

                        if (v.Model.GetDimensions().Y > 6f)
                        {
                            UI.Notify("~o~The" + v.FriendlyName + " is too long for this carrier.");

                            return;
                        }
                    }
                   else if (carrier.Model == "flatbed")
                    {
                        float farback = 4f;
                        if (v.Model.GetDimensions().Y > 4) farback = -(4.5f+(v.Model.GetDimensions().Y-5));
                        /*
                        if (v.Model.GetDimensions().Y > 8) farback = -7.5f;
                        if (v.Model.GetDimensions().Y > 9) 
                        {
                            UI.Notify("~o~The" + v.FriendlyName + " is too long for this carrier.");

                            return;
                        }
                        */
                        offset = new Vector3(0, farback,height); // v.Model.GetDimensions().Z * 0.5f  //
                        truckoffset = new Vector3(0f,0f, -0.4f);//offset.Z * 0.4f);

                    }
                    else if(carrier.Model == "yosemitexl")
                    {                        
                        offset = new Vector3(0, -3.6f,height+1f); // v.Model.GetDimensions().Z * 0.5f
                        truckoffset = new Vector3(0f, (v.Model.GetDimensions().Y / 2f),0f );

                    }
                    else if (carrier.Model == "wastelander")
                    {
                        offset = new Vector3(0, -1.5f, height); // v.Model.GetDimensions().Z * 0.5f
                        truckoffset = new Vector3(0f, (v.Model.GetDimensions().Y / 2f), -0.9f);

                    }
                    else
                    {
                        CarrierIsNormalVehicle = true;
                    }

                }

                if (CarrierIsNormalVehicle)
                {
                    float CarrierOffset = (carrier.Model.GetDimensions().Y / 2);
                    float vOffset = -(v.Model.GetDimensions().Y / 2);
                    Function.Call(Hash.ATTACH_ENTITY_TO_ENTITY_PHYSICALLY, v, carrier, 0, 0, 0f, vOffset, v.HeightAboveGround -carrier.HeightAboveGround,0, CarrierOffset, 0f, 0f, 0f, 0f, 2000f, false, true, true, false, 2); //+ (v.Model.GetDimensions().Y/2f)
                    //edit void ATTACH_ENTITY_TO_ENTITY_PHYSICALLY(Entity entity1, Entity entity2, int boneIndex1, int boneIndex2, float xPos1, float yPos1, float zPos1, float xPos2, float yPos2, float zPos2, float xRot, float yRot, float zRot, float breakForce, BOOL fixedRot, BOOL p15, BOOL collision, BOOL p17, int p18) // C3675780C92F90F9 0547417F
                }
                else
                {
                    Function.Call(Hash.ATTACH_ENTITY_TO_ENTITY_PHYSICALLY, v, carrier, 0, 0, 0f, offset.Y + (v.Model.GetDimensions().Y / 2f), offset.Z, truckoffset.X, truckoffset.Y, truckoffset.Z, 0f, 0f, 0f, 2000f, true, true, true, false, 2); //+ (v.Model.GetDimensions().Y/2f)
                }

                /* Rope system
             v.Detach();

             Script.Wait(1000);
             Vector3 dynamicoffset = v.GetOffsetFromWorldCoords(carrier.Position);
             //Function.Call(Hash.ATTACH_ENTITY_TO_ENTITY_PHYSICALLY, v, carrier, 0, 0, 0f, 2f, 0f, dynamicoffset.X, dynamicoffset.Y+2f, dynamicoffset.Z, v.Rotation.X, 0f, 0f, 1000f, false, true, true, true, 2); //+ (v.Model.GetDimensions().Y/2f)

             float yoffset = v.Model.GetDimensions().Y/2;
             Rope rope = World.AddRope(RopeType.Normal, v.Position, v.Rotation, v.Position.DistanceTo(carrier.Position), 1f, false);
             rope.ActivatePhysics();
             rope.AttachEntities(v, v.Position+(v.ForwardVector* yoffset), carrier, v.Position + (v.ForwardVector * yoffset) - v.UpVector, (v.Position + (v.ForwardVector * yoffset)).DistanceTo(v.Position + (v.ForwardVector * yoffset) - v.UpVector));
             TrailerRopes.Add(rope);

              yoffset = v.Model.GetDimensions().Y / 2;
              rope = World.AddRope(RopeType.Normal, v.Position, v.Rotation, v.Position.DistanceTo(carrier.Position), 1f, false);
             rope.ActivatePhysics();
             rope.AttachEntities(v, v.Position - (v.ForwardVector * yoffset), carrier, v.Position - (v.ForwardVector * yoffset) - v.UpVector, (v.Position - (v.ForwardVector * yoffset)).DistanceTo(v.Position - (v.ForwardVector * yoffset) - v.UpVector));
             TrailerRopes.Add(rope);
             */
            }
        }
        if (WasCheatStringJustEntered("detach"))
        {

                Vehicle carrier = Game.Player.Character.CurrentVehicle;
                foreach (Vehicle t in World.GetNearbyVehicles(carrier.Position, 30f)) if (t.Model == "freighttrailer") { carrier = t; break; }

            if (CanWeUse(carrier))
            {

                if (carrier.IsAttached()) carrier.Detach();
                //foreach (Rope r in TrailerRopes) if (r.Exists() && r.GetVertexCoord(0).DistanceTo(carrier.Position) < 10f) r.Delete();

                //carrier.Detach();     
                           
                foreach (Vehicle veh in World.GetNearbyVehicles(Game.Player.Character.Position, 20f)) if (veh != carrier && veh.IsTouching(carrier) || veh.IsAttachedTo(carrier) || carrier.IsAttachedTo(veh))
                    {
                        veh.Position = carrier.Position - (carrier.ForwardVector * carrier.Model.GetDimensions().Y);
                        UI.Notify("Detaching "+veh.FriendlyName+" from "+carrier.FriendlyName);
                        veh.Detach();
                    }
            }
        }
        if (WasCheatStringJustEntered("car"))
        {
            UI.Notify("Current car "+Game.Player.Character.CurrentVehicle.DisplayName);
        }
            if (WasCheatStringJustEntered("lwpos"))
        {
            Vector3 pos = Game.Player.Character.Position;
            string t = "";
            t = t + "Vector3 (" + pos.X + "," + pos.Y + "," + pos.Z + ");";
            File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n"+ t);

            UI.Notify(t);

        }
        if (WasCheatStringJustEntered("lwcarjacker"))
        {
            UI.Notify("Called for a carjacker event.");
            CarjackerEnabled = true;
        }

        if (WasCheatStringJustEntered("lwtraffictest"))
        {
            UI.Notify("~b~Calling for all injected vehicles:");
            foreach(TrafficSpawner t in TrafficSpawnerList)
            {
                t.Cooldown = Game.GameTime + (RandomInt(1, 10) * 1000);
                //UI.Notify(t.SourceVehicle.ToString());
            }
        }
        if (WasCheatStringJustEntered("lwtow"))
        {
            SpawnTow();
            UI.Notify("Called for a Tow event.");

        }
        if (WasCheatStringJustEntered("lwhook"))
        {
            UI.Notify("received.");
            Vehicle veh = Game.Player.Character.CurrentVehicle;

            if (CanWeUse(veh))
            {
                foreach (Vehicle v in World.GetNearbyVehicles(veh.Position, 5f))
                {
                    if(v.Handle != veh.Handle)
                    {
                        if (v.IsAttachedTo(veh))
                        {
                            v.Detach();
                        }
                        else
                        {
                            //attach respecting offset Vector3 relativePos = Function.Call<Vector3>(Hash.GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS, veh, v.Position.X,v.Position.Y,v.Position.Z);
                            Vector3 relativePos = new Vector3(0, -2, 0.7f + (v.Model.GetDimensions().Z / 5)); //

                            /*v.Position = veh.Position + (veh.ForwardVector*-2)+(veh.UpVector*3f);
                            v.Heading = veh.Heading;
                            v.Speed = veh.Speed;*/
                            v.AttachTo(veh, 0, relativePos, new Vector3(0, 0, 0));
                            v.Detach();
                            Script.Wait(1000);

                            Vector3 hook = Function.Call<Vector3>(Hash.GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS, veh, v.Position.X, v.Position.Y, v.Position.Z);
                            //relativePos = new Vector3(relativePos.X, -relativePos.Y, -relativePos.Z);
                            v.AttachTo(veh, 0, hook,new Vector3(0,0,0));
                        }
                    }
                }
            }

        }
        if (WasCheatStringJustEntered("lwfreight"))
        {
            UI.Notify("Called for a Freight event.");
            HandleFreightTrucks();

        }
        if (WasCheatStringJustEntered("lwdebugoutput"))
        {
            DebugOutput = !DebugOutput;
            UI.Notify("~b~Debug output is now " + DebugOutput);
        }

        if (WasCheatStringJustEntered("lwdrivebyb"))
        {
            UI.Notify("DriveBy Spawned (Ballas)");
            SpawnGangDriveBy(Gang.Ballas, World.GetClosestPed(Game.Player.Character.Position.Around(30f), 20f));
        }
        if (WasCheatStringJustEntered("lwdrivebyf"))
        {
            UI.Notify("DriveBy Spawned (Families)");
            SpawnGangDriveBy(Gang.Families, World.GetClosestPed(Game.Player.Character.Position.Around(30f), 20f));
        }
        if (WasCheatStringJustEntered("lwdrivebyl"))
        {
            UI.Notify("DriveBy Spawned  (Lost)");
            SpawnGangDriveBy(Gang.Lost, World.GetClosestPed(Game.Player.Character.Position.Around(30f), 20f));
        }
        if (WasCheatStringJustEntered("lwdrivebyv"))
        {
            UI.Notify("DriveBy Spawned (Vagos)");
            SpawnGangDriveBy(Gang.Vagos, World.GetClosestPed(Game.Player.Character.Position.Around(30f), 20f));
        }

        if (WasCheatStringJustEntered("lwzonename"))
        {
            string text = "";
            text += "Zone:" + GetZoneName(Game.Player.Character.Position);
            text += "~n~Street:" + World.GetStreetName(Game.Player.Character.Position);
            text += "~n~Zone:" + World.GetZoneName(Game.Player.Character.Position);
            text += "~n~ZoneLabel:" + World.GetZoneNameLabel(Game.Player.Character.Position);

            UI.Notify(text);
        }
        if (WasCheatStringJustEntered("lwhunter"))
        {
            UI.Notify("Called for a Hunter event.");

            Vector3 pos = World.GetSafeCoordForPed(Game.Player.Character.Position.Around(100), false); //GenerateSpawnPos(Game.Player.Character.Position.Around(50),Nodetype.Offroad,false)
            Hunters.Add(new Hunter(pos));
        }
        if (WasCheatStringJustEntered("lwanimaltrophy"))
        {
            UI.Notify("Called for an Animal Trophy event.");

            SpawnAnimalTrophy();
        }
        if (WasCheatStringJustEntered("lwambulance"))
        {
            UI.Notify("Called for an Ambulance event.");

            SpawnEmergencyVehicle(EmergencyType.AMBULANCE);
        }
        if (WasCheatStringJustEntered("lwpolice"))
        {
            UI.Notify("Called for a Police event.");

            SpawnEmergencyVehicle(EmergencyType.POLICE);
        }
        if (WasCheatStringJustEntered("lwfiretruck"))
        {
            UI.Notify("Called for a Firetruck event.");
            SpawnEmergencyVehicle(EmergencyType.FIRETRUCK);
        }
        if (WasCheatStringJustEntered("lwdebug")) { Debug = !Debug; UI.Notify("~b~Debug set to " + Debug.ToString()); }
        if (WasCheatStringJustEntered("lwblips")) { DebugBlips = !DebugBlips; UI.Notify("~b~DebugBlips set to " + DebugBlips.ToString()); }

        if (WasCheatStringJustEntered("lwtaxi"))
        {
            UI.Notify("Called for a Taxi event.");

            SpawnTaxiEvent();
        }
        if (WasCheatStringJustEntered("lwcarmeet"))
        {
            SpawnCarMeet();
        }

        if (WasCheatStringJustEntered("lwdealp"))
        {
            UI.Notify("Called for a Deal event (private).");

            SpawnDrugDeal(false);
        }
        if (WasCheatStringJustEntered("lwdeal"))
        {
            UI.Notify("Called for a Deal event. (Automatic)");

            SpawnDrugDeal(IsInNamedArea(Game.Player.Character, "desrt"));
        }
        if (WasCheatStringJustEntered("lwdealg"))
        {
            UI.Notify("Called for a Gang Deal event. (Gang)");
            SpawnDrugDeal(true);
        }
    }
    void ProcessLists()
    {
        if (BlacklistedVehicles.Count > 20)
        {
            BlacklistedVehicles.RemoveRange(0, 5);
            if (Debug) UI.Notify("~b~ BlacklistedVehicles list pruned.");
        }

        //Blacklisted events cooldown
        if (BlacklistedEvents.Count > 0)
        {
            if (Debug)
            {
                string text = "";
                foreach (EventType ev in BlacklistedEvents) text = text + " | " + ev.ToString();
                DisplayHelpTextThisFrame("Blacklisted events:" + text);
            }
            if (BlackistedEventsTime < Game.GameTime)
            {
                if (BlackistedEventsTime == 0) BlackistedEventsTime = Game.GameTime + 40000;
                else
                {
                    BlackistedEventsTime = BlackistedEventsTime = Game.GameTime + 40000;
                    BlacklistedEvents.RemoveAt(0);
                    if (Debug) UI.Notify("~b~Blacklisted events cleared");
                }
            }
        }

        //Blacklisted Important events cooldown
        /*
        if (BlacklistedImportantEvents.Count > 1)
        {
            if (Debug)
            {
                string text = "";
                foreach (EventType ev in BlacklistedImportantEvents) text = text + " | " + ev.ToString();
                UI.ShowSubtitle("Blacklisted Important events:" + text);
            }
            if (BlackistedImportantEventsTime < Game.GameTime)
            {
                if (BlackistedImportantEventsTime == 0) BlackistedImportantEventsTime = Game.GameTime + (60000 * BlackistedImportantEventsCooldown);//change to 5 in release
                else
                {
                    BlackistedImportantEventsTime = BlackistedImportantEventsTime = Game.GameTime + (60000 * BlackistedImportantEventsCooldown); //change to 5 in release
                    BlacklistedImportantEvents.RemoveAt(0);
                    if (Debug) UI.Notify("~b~Blacklisted Important events cleared");
                }
            }
        }*/


        //Get all neccesary vehicles 
        if (VehMonitorTime < Game.GameTime)
        {
            VehMonitorTime = Game.GameTime + 5000;
            MonitoredVehicles.Clear();
            AllVehicles.Clear();

            string names = "";

            foreach (Vehicle v in World.GetAllVehicles())
            {
                AllVehicles.Add(v);
                if (!v.PreviouslyOwnedByPlayer && MonitoredModels.Contains(v.Model))//!v.PreviouslyOwnedByPlayer && 
                {
                    if (!BlacklistedModels.Contains(v.Model))
                    {
                        MonitoredVehicles.Add(v);
                        names = names + " |  ~g~" + v.FriendlyName + "~w~";
                    }
                    else
                    {
                        names = names + " | ~o~" + v.FriendlyName + "~w~";
                    }
                }
                if (TruckRespray && Respraymodels.Contains(v.Model) && !BlacklistedVehicles.Contains(v) && !Game.Player.Character.IsInRangeOf(v.Position, 40f)) { ResprayTruck(v); BlacklistedVehicles.Add(v); }
            }

            if (BlacklistedModels.Count > 5)
            {
                BlacklistedModels.RemoveAt(0);
                if (Debug) UI.Notify("~y~Blacklist cleaned");
            }

            AllPeds.Clear();
            foreach (Ped p in World.GetAllPeds())
            {
                if (!p.IsPlayer && !p.IsPersistent)
                {
                    AllPeds.Add(p);
                }
            }

            if (Debug) UI.Notify(MonitoredVehicles.Count + " specific cars being monitored of " + AllVehicles.Count + ". ~n~(" + names + ")");

        }

    }

    void ProcessCurrentEvents()
    {
        //Each second
        if (Interval < Game.GameTime)
        {
            Interval = Game.GameTime + 1000;


            //Handlers

            if (FreightTruckCooldown < Game.GameTime) HandleFreightTrucks();
            HandleFlabeds();

            HandleCarjacker();
            int prob = 1;
            if (IsNightTime()) prob += 2;
            if (IsInNamedArea(Game.Player.Character, "city") && RandomInt(0, 10) <= 2)

                //if(Game.Player.Character.IsInRangeOf(NoEventsHere,500f)

                if (TemporalPersistence.Count > 0)
                {
                    if(Debug) UI.Notify("Persistent entities: "+TemporalPersistence.Count);
                    for (int i = 0; i < TemporalPersistence.Count - 1; i++)
                    {
                        if (!CanWeUse(TemporalPersistence[i]))
                        {
                            TemporalPersistence.RemoveAt(i);
                            break;
                        }
                        else
                        {
                            if (!TemporalPersistence[i].IsInRangeOf(Game.Player.Character.Position, 400f))
                            {
                                if (Debug) UI.Notify("Removing persistent "+ TemporalPersistence[i].ToString()+ "");
                                TemporalPersistence[i].IsPersistent = false;
                                TemporalPersistence.RemoveAt(i);
                            }
                        }
                    }
                }



            if (Taxis.Count > 0)
            {
                if (Taxis[0].Finished)
                {
                    Taxis[0].Clear();
                    Taxis.RemoveAt(0);
                }
                else foreach (TaxiEvent t in Taxis) t.Process();
            }

            if (DrugDeals.Count > 0)
            {
                if (DrugDeals[0].Finished)
                {
                    DrugDeals[0].Clear();
                    DrugDeals.RemoveAt(0);
                }
                else foreach (DrugDeal deal in DrugDeals) deal.Process();
            }


            if (Hunters.Count > 0)
            {
                if (Hunters[0].Finished)
                {
                    Hunters[0].Clear();
                    Hunters.RemoveAt(0);
                }
                else foreach (Hunter h in Hunters) h.Process();
            }
        }
    }


    int InteractionCooldown = 20000;
    int InteractionFrecuency = 50;

    void EventGenerator()
    {
        //Ambient
        if (SmallEventCooldownTime < Game.GameTime) //Interactive World events
        {
            SmallEventCooldownTime = Game.GameTime + InteractionCooldown; //future InteractionCooldown 

            if (!BlacklistedAreas.Contains(World.GetZoneNameLabel(Game.Player.Character.Position).ToLowerInvariant()))
            {
                if (RandomInt(0, 100) < InteractionFrecuency) Scenarios();
            }
            else if (Debug) UI.Notify("Player is in restricted area, Scenarios disabled.");
        }

        //Spawner
        if (SpawnerEventCooldownTime < Game.GameTime) //Spawner events
        {
            SpawnerEventCooldownTime = Game.GameTime + EventCooldown;
            if (!BlacklistedAreas.Contains(World.GetZoneNameLabel(Game.Player.Character.Position).ToLowerInvariant())) HandleSpawnerEvents(); else if (Debug) UI.Notify("Player is in restricted area, SpawnerEvents disabled.");
            //if (AllVehicles.Count > 5) HandleSpawnerEvents(); else if (Debug) { UI.Notify("~b~[Ambient Events]~w~: Not enough traffic to spawn anything."); SpawnerEventCooldownTime = Game.GameTime + 60000; }
        }

        //Car replacer
        if (ReplacerTime < Game.GameTime) //Replacers
        {
            ReplacerTime = Game.GameTime + 10000;
            if (TrafficInjector)
            {
                foreach (TrafficSpawner tr in TrafficSpawnerList)
                    if (tr.Process())
                    {
                        ReplacerTime = Game.GameTime + 5000;
                        break;
                    }
            }
            if (VehicleReplacer) foreach (Replacer ev in ReplacersList) if (!BlacklistedModels.Contains(Game.GenerateHash(ev.SourceVehicle))) if (ev.Process()) break;
        }
    }
    public static double AngleBetween(Vector3 u, Vector3 v, bool returndegrees)
    {
        double toppart = 0;
        for (int d = 0; d < 3; d++) toppart += u[d] * v[d];

        double u2 = 0; //u squared
        double v2 = 0; //v squared
        for (int d = 0; d < 3; d++)
        {
            u2 += u[d] * u[d];
            v2 += v[d] * v[d];
        }

        double bottompart = 0;
        bottompart = Math.Sqrt(u2 * v2);


        double rtnval = Math.Acos(toppart / bottompart);
        if (returndegrees) rtnval *= 360.0 / (2 * Math.PI);
        return rtnval;
    }

    int t = 0;
    void OnTick(object sender, EventArgs e)
    {
        //DisplayHelpTextThisFrame(AnyVehicleNear(Game.Player.Character.Position, 30f).ToString());

        /*
        if(CanWeUse(Game.Player.Character.CurrentVehicle))
        {
            if (t < Game.GameTime)
            {
                t = Game.GameTime + 500;
                Function.Call(Hash.REQUEST_NAMED_PTFX_ASSET, "core");
                if (Function.Call<bool>(Hash.HAS_NAMED_PTFX_ASSET_LOADED, "core"))
                {
                    Function.Call(Hash._SET_PTFX_ASSET_NEXT_CALL, "core");
                    Function.Call<int>(Hash.START_PARTICLE_FX_NON_LOOPED_ON_ENTITY, "exp_grd_vehicle_post", Game.Player.Character.CurrentVehicle, 0.0f, 0.0f, 0.0f, 0, 0, 0, 0.7f, 0, 1, 0);
                }
            }

        }
        */

        //DisplayHelpTextThisFrame("Heading:" +Game.Player.Character.Heading+", difference: " +(AngleBetweenVectors(Game.Player.Character.Position, GameplayCamera.Position)).ToString());

        HandleNotifications();
        HandleConversation();
        HandleMessages();
        if (Game.IsControlJustPressed(2, GTA.Control.Context))
        {
            if (Hunters.Count > 0 && Hunters[0].HunterPed.IsInRangeOf(Game.Player.Character.Position,15) && !Hunters[0].HunterPed.IsInCombat)
            {
                LivelyWorld.AddQueuedConversation("~b~[" + Game.Player.Name + "]:~w~ Hey pal, that direction.");
                Hunters[0].HelpHunter();
            }
        }
        EventGenerator();
        ProcessCheats();
        ProcessLists();
        ProcessCurrentEvents();
    }


    public Vehicle CarjackerTarget = null;
    public Ped Carjacker = null;
    bool CarjackerEnabled;
    int CarjackerPhase = 0;
    int LookOutTime = 0;
    public void HandleCarjacker()
    {
        if (DisabledEvents.Contains(EventType.Carjacker)) return;
        if (CarjackerEnabled)
        {

            if(CarjackerPhase != 0 && (!CanWeUse(Carjacker) || !CanWeUse(CarjackerTarget) || Carjacker.IsInCombat || Carjacker.IsDead || !Carjacker.IsInRangeOf(Game.Player.Character.Position,200f)))
            {
                
                if (CanWeUse(Carjacker))
                {
                    if (Carjacker.CurrentBlip.Exists()) Carjacker.CurrentBlip.Remove();
                    Carjacker.IsPersistent = false;
                }
                CarjackerEnabled = false;
                CarjackerPhase = 0;
                if (Debug) UI.Notify("~r~Carjacker event cancelled.");
                return;
            }
            switch (CarjackerPhase)
            {
                case 0:
                    {
                        if (!CanWeUse(Carjacker))
                        {
                            foreach (Vehicle veh in AllVehicles)
                            {
                                if (!WouldPlayerNoticeChangesHere(veh.Position) && veh.IsStopped && !CanWeUse(veh.Driver) && veh.IsInRangeOf(Game.Player.Character.Position, InteractionRange))
                                {
                                    CarjackerTarget = veh;
                                    CarjackerTarget.IsPersistent = true;
                                   if(Debug) UI.Notify("~b~[Carjacker]~w~ got vehicle to jack");
                                    break;
                                }
                            }

                            Vector3 pos =  World.GetSafeCoordForPed(CarjackerTarget.Position.Around(20)); // Game.Player.Character.Position.Around(5);//GetQuietPlace();
                            //if (pos == Vector3.Zero) pos = GenerateSpawnPos(Game.Player.Character.Position.Around(50), Nodetype.AnyRoad, true);
                            Carjacker = World.CreatePed("s_m_y_dealer_01", pos, 0);
                            Carjacker.AlwaysKeepTask = true;
                            Carjacker.Weapons.Give(WeaponHash.Pistol, 60, false, true);

                            if (DebugBlips && !Carjacker.CurrentBlip.Exists())
                            {
                                Carjacker.AddBlip();
                                Carjacker.CurrentBlip.Scale = 0.5f;
                                Carjacker.CurrentBlip.IsShortRange = true;
                            }

                            CarjackerPhase++;
                            if (Debug) UI.Notify("carjacker created");
                            
                        }
                        break;
                    }
                case 1:
                    {
                        if (!Carjacker.IsInRangeOf(CarjackerTarget.Position, 5f))
                        {
                            if (IsIdle(Carjacker))
                            {
                                if (Debug) UI.Notify("~b~[Carjacker]~w~ tasked to go to target");

                                Function.Call(Hash.TASK_GO_TO_ENTITY, Carjacker, CarjackerTarget, -1, 3f, 1f, 1073741824, 0);
                            }
                            //Function.Call(Hash.TASK_PAUSE, 0, RandomInt(3, 8) * 1000);
                        }
                        else CarjackerPhase++;
                        break;
                    }
                case 2:
                    {
                        if (Debug) UI.Notify("~b~[Carjacker]~w~ looking around");
                        LookOutTime = Game.GameTime + 10000;
                        TaskSequence seq = new TaskSequence();


                        Function.Call(Hash.TASK_START_SCENARIO_IN_PLACE, 0, "CODE_HUMAN_CROSS_ROAD_WAIT", 8000, true);

                        seq.Close();
                        Carjacker.Task.PerformSequence(seq);
                        seq.Dispose();
                        Carjacker.BlockPermanentEvents = false;
                        CarjackerPhase++;
                        break;
                    }
                case 3:
                    {
                        if (LookOutTime<Game.GameTime)
                        {

                            if (isCopInRange(CarjackerTarget.Position, 30f) || Game.Player.Character.IsInRangeOf(Carjacker.Position, 20f))
                            {
                                if (Debug) UI.Notify("~b~[Carjacker]~w~ cops nearby, jacker leaves the scene");
                                Function.Call(Hash.TASK_WANDER_STANDARD, Carjacker, 100f, 10f);

                            }
                            else 
                            {
                                if (Debug) UI.Notify("~b~[Carjacker]~w~ no cops nearby, jacking");

                                TaskSequence seq = new TaskSequence();
                                Function.Call(Hash.TASK_ENTER_VEHICLE, 0, CarjackerTarget, 20000, -1, 1f, 1, 0);
                                Function.Call(Hash.TASK_PAUSE, 0, RandomInt(2, 4) * 1000);

                                Function.Call(Hash.TASK_VEHICLE_DRIVE_WANDER, 0, CarjackerTarget, 30f, 4 + 8 + 16 + 32);

                                seq.Close();
                                Carjacker.Task.PerformSequence(seq);
                                seq.Dispose();
                            }
                            CarjackerPhase++;
                        }
                        break;
                    }
                case 4:
                    {
                        if (Carjacker.IsJacking) Carjacker.RelationshipGroup = CriminalRelGroup;

                        if (Carjacker.IsInVehicle(CarjackerTarget) || !Carjacker.IsInRangeOf(Game.Player.Character.Position,100f))
                        {
                            if (Carjacker.CurrentBlip.Exists()) Carjacker.CurrentBlip.Color = BlipColor.White;

                            CarjackerTarget.IsPersistent = false;
                            Carjacker.IsPersistent = false;
                            if (Debug) UI.Notify("~b~[Carjacker]~w~ Carjacker event finished");
                            CarjackerEnabled = false;
                            CarjackerPhase = 0;
                        }
                        break;
                    }
            }
        }
        else if (CarjackerPhase != 0) CarjackerPhase = 0;
    }

    public bool IsIdle(Ped ped)
    {
        if (ped.IsInCombat || !ped.IsStopped || ped.IsRagdoll) return false; else return true;
    }
    public static Random rnd = new Random();
    public static int RandomInt(int min, int max)
    {
        max++;
        return rnd.Next(min, max);
    }

    public enum Gang { Lost, Ballas, Vagos, Families};
    public void SpawnGangDriveBy(Gang g, Ped victim)
    {


        if (!CanWeUse(victim)) return;
        victim.IsPersistent = true;

        if (Debug) UI.Notify("victim exists");

        Vector3 pos = GenerateSpawnPos(Game.Player.Character.Position.Around(100), Nodetype.Road, false);
        //if (pos == Vector3.Zero) pos = GenerateSpawnPos(Game.Player.Character.Position, Nodetype.Road, false);
        Vehicle veh = null;
        List<Ped> Peds = new List<Ped>();

        if (Debug) UI.Notify("setting rlgroups");

        int HateRLGroup = World.AddRelationshipGroup("hatetemp");
        int VictimRLGroup = World.AddRelationshipGroup("victimtemp");
        victim.RelationshipGroup = VictimRLGroup;
       foreach (Ped p in World.GetNearbyPeds(victim,40f))
        {
            World.SetRelationshipBetweenGroups(Relationship.Respect, VictimRLGroup, p.RelationshipGroup);

            World.SetRelationshipBetweenGroups(Relationship.Respect, p.RelationshipGroup, VictimRLGroup);
        }


        World.SetRelationshipBetweenGroups(Relationship.Hate, HateRLGroup, victim.RelationshipGroup);
        World.SetRelationshipBetweenGroups(Relationship.Hate, victim.RelationshipGroup, HateRLGroup);
        if (Debug) UI.Notify("checking king of gang");

        switch (g)
        {
            case Gang.Ballas:
                {
                    veh = World.CreateVehicle("tornado", pos);
                    veh.PrimaryColor = VehicleColor.MetallicPurple;
                    veh.SecondaryColor = VehicleColor.MatteDesertBrown;

                    for (int i= 0; i< veh.PassengerSeats+1; i++)
                    {                        
                        Ped ped = World.CreatePed(BallasModels[RandomInt(0,BallasModels.Count-1)], veh.Position.Around(5));
                        ped.RelationshipGroup = HateRLGroup;
                        ped.Weapons.Give(WeaponHash.Pistol, 99, true, true);

                        Peds.Add(ped);
                    }
                    break;
                }
            case Gang.Lost:
                {
                    veh = World.CreateVehicle("gburrito", pos);
                    veh.PrimaryColor = VehicleColor.MatteBlack;
                    for (int i = 0; i < veh.PassengerSeats+1; i++)
                    {
                        Ped ped = World.CreatePed(LostModels[RandomInt(0, LostModels.Count - 1)], veh.Position.Around(5));
                        ped.RelationshipGroup = HateRLGroup;
                        ped.Weapons.Give(WeaponHash.Pistol, 99, true, true);
                        Peds.Add(ped);
                    }
                    break;
                }
            case Gang.Vagos:
                {
                    veh = World.CreateVehicle("buccaneer", pos);
                    veh.PrimaryColor = VehicleColor.MetallicTaxiYellow;
                    veh.SecondaryColor = VehicleColor.MetallicTaxiYellow;

                    for (int i = 0; i < veh.PassengerSeats+1; i++)
                    {
                        Ped ped = World.CreatePed(VagosModels[RandomInt(0, VagosModels.Count - 1)], veh.Position.Around(5));
                        ped.RelationshipGroup = HateRLGroup;
                        ped.Weapons.Give(WeaponHash.Pistol, 99, true, true);
                        Peds.Add(ped);
                    }
                    break;
                }
            case Gang.Families:
                {
                    veh = World.CreateVehicle("baller", pos);
                    veh.PrimaryColor = VehicleColor.MetallicGreen;
                    for (int i = 0; i < veh.PassengerSeats+1; i++)
                    {
                        Ped ped = World.CreatePed(FamiliesModels[RandomInt(0, FamiliesModels.Count - 1)], veh.Position.Around(5));
                        ped.RelationshipGroup = HateRLGroup;
                        ped.Weapons.Give(WeaponHash.Pistol, 99, true, true);
                        Peds.Add(ped);
                    }
                    break;
                }
        }
        if (Debug) UI.Notify("setting up gang");

        if (DebugBlips)
        {
            veh.AddBlip();
            veh.CurrentBlip.Sprite = BlipSprite.GunCar;
            veh.CurrentBlip.IsShortRange = true;
        }
             SetPedsIntoVehicle(Peds, veh);

        Script.Wait(1000);
            Ped driver = veh.Driver;
            if (!CanWeUse(driver))
        {
            if (Debug) UI.Notify("No driver!");
            driver = Peds[0];
        }
        MoveEntitytoNearestRoad(veh,true,true);
        if (Debug) UI.Notify("tasking gang");

        TaskSequence seq = new TaskSequence();
        Function.Call(Hash.TASK_ENTER_VEHICLE, 0, veh, 20000, -1, 1f, 1, 0);
        Function.Call(Hash.TASK_VEHICLE_MISSION_PED_TARGET, 0, veh, victim, 4, 20f, 4 + 8 + 16 + 32, 20f, 10f, 2f, true, 1101004800);
        Function.Call(Hash.TASK_PAUSE, 0, RandomInt(2, 4) * 1000);
        Function.Call(Hash.TASK_VEHICLE_MISSION_PED_TARGET, 0, veh, victim, 8, 60f, 4 + 8 + 16 + 32, 20f, 10f, 2f, true, 1101004800);
        seq.Close();
        driver.Task.PerformSequence(seq);
        seq.Dispose();

        foreach (Ped ped in Peds) TemporalPersistence.Add(ped);
        TemporalPersistence.Add(veh);
        TemporalPersistence.Add(victim);

        if (!victim.CurrentBlip.Exists() && !victim.IsPlayer)
        {
            victim.AddBlip();
            victim.CurrentBlip.Color = BlipColor.White;
            victim.CurrentBlip.Scale = 0.7f;
            victim.CurrentBlip.Name = "Victim";
            victim.CurrentBlip.IsShortRange = true;
        }


        if (Debug) UI.Notify("finished");
        GangDrivebyCooldown = Game.GameTime + 60 * 1000 * (RandomInt(2, 5));
    }
    public static void RandomTuning(Vehicle veh, bool neons, bool horn)
    {
        Function.Call(Hash.SET_VEHICLE_MOD_KIT, veh, 0);

        //Change color
        var color = Enum.GetValues(typeof(VehicleColor));
        Random random = new Random();
        veh.PrimaryColor = (VehicleColor)color.GetValue(random.Next(color.Length));

        Random random2 = new Random();
        veh.SecondaryColor = (VehicleColor)color.GetValue(random2.Next(color.Length));

        if (veh.LiveryCount > 0) veh.Livery = RandomInt(0, veh.LiveryCount);

        //Change tuning parts
        foreach (int mod in Enum.GetValues(typeof(VehicleMod)).Cast<VehicleMod>())
        {
            if (mod == (int)VehicleMod.Horns && !horn) continue;
            veh.SetMod((VehicleMod)mod, RandomInt(0, veh.GetModCount((VehicleMod)mod)), false);
        }

        if (neons)
        {

            //Color neoncolor = Color.FromArgb(0, Util.GetRandomInt(0, 255), Util.GetRandomInt(0, 255), Util.GetRandomInt(0, 255));

            Color neoncolor = Color.FromKnownColor((KnownColor)RandomInt(0, Enum.GetValues(typeof(KnownColor)).Cast<KnownColor>().Count()));
            veh.NeonLightsColor = neoncolor;

            veh.SetNeonLightsOn(VehicleNeonLight.Front, true);
            veh.SetNeonLightsOn(VehicleNeonLight.Back, true);
            veh.SetNeonLightsOn(VehicleNeonLight.Left, true);
            veh.SetNeonLightsOn(VehicleNeonLight.Right, true);

        }
    }
    public static bool CanPedSeePed(Ped watcher, Ped target, bool WatcherIsPlayer)
    {
        RaycastResult ray;
        if (WatcherIsPlayer)
        {
            if (watcher.IsInRangeOf(target.Position, 10f)) return true;
            ray = World.Raycast(GameplayCamera.Position, target.Position, Game.Player.Character.Position.DistanceTo(target.Position), IntersectOptions.Map, Game.Player.Character);
        }
        else
        {
            ray = World.Raycast(watcher.Position, target.Position, IntersectOptions.Map);
        }
        if (!ray.DitHitAnything || ray.HitCoords.DistanceTo(target.Position) < 10f) return true;
        return false;
    }

    public static bool CanPedSeePos(Ped watcher, Vector3 target, bool WatcherIsPlayer)
    {
        //if (!watcher.IsInRangeOf(target, 150f)) return false;

        RaycastResult ray;
        if (WatcherIsPlayer)
        {
            if (watcher.IsInRangeOf(target, 10f)) return true;
            ray = World.Raycast(GameplayCamera.Position, target, GameplayCamera.Position.DistanceTo(target)+5, IntersectOptions.Map);
        }
        else
        {
            ray = World.Raycast(watcher.Position, target, IntersectOptions.Map);
        }



        if (ray.DitHitAnything)
        {
            //UI.Notify("cannot see");
            return false; //&& ray.HitCoords.DistanceTo(target) > 10f && ray.HitCoords.DistanceTo(watcher.Position) < 10f
        }
        //UI.Notify("can see");

        return true;
    }
    public static bool WouldPlayerNoticeChangesHere(Vector3 pos)
    {
        if (!Function.Call<bool>(Hash.WOULD_ENTITY_BE_OCCLUDED, Game.GenerateHash("blista"), pos.X, pos.Y, pos.Z, true)) return true;
        //if (CanPedSeePos(Game.Player.Character, pos, true)) return true;
        return false;
    }
    public static bool isCopInRange(Vector3 Location, float Range)
    {
        return Function.Call<bool>(Hash.IS_COP_PED_IN_AREA_3D, Location.X - Range, Location.Y - Range, Location.Z - Range, Location.X + Range, Location.Y + Range, Location.Z + Range);
    }
    public static bool isCopVehicleRange(Vector3 Location, float Range)
    {
        return Function.Call<bool>(Hash.IS_COP_VEHICLE_IN_AREA_3D, Location.X - Range, Location.Y - Range, Location.Z - Range, Location.X + Range, Location.Y + Range, Location.Z + Range);
    }

    public static bool WasCheatStringJustEntered(string cheat)
    {
        return Function.Call<bool>(Hash._0x557E43C447E700A8, Game.GenerateHash(cheat));
    }

    public static void ReplaceVehicle(Vehicle v, Model target, bool tuning)
    {
         if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Replacing"+v.DisplayName +" with "+target.ToString());

        //LivelyWorld.BlacklistedModels.Add(v.Model.ToString());
        if (CanWeUse(v))
        {
            Vector3 pos = v.Position;
            float speed = v.Speed;
            float heading = v.Heading;
            Ped ped = v.Driver;
            bool HadDriver = LivelyWorld.CanWeUse(ped);
            Vehicle possibletrailer = LivelyWorld.GetTrailer(v);

            if (CanWeUse(possibletrailer))
            {
                 if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - truck had trailer");

                Function.Call(Hash.DETACH_VEHICLE_FROM_TRAILER, v);
                possibletrailer.IsPersistent = true;
                Script.Wait(500);

            }
            v.Delete();

            Vehicle veh = World.CreateVehicle(target, pos, heading);

            if (LivelyWorld.CanWeUse(veh))
            {
                 if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - replacer car created");

                veh.Speed = speed;

                if (!veh.CurrentBlip.Exists() && LivelyWorld.DebugBlips)
                {
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - adding blip");

                    veh.AddBlip();
                    veh.CurrentBlip.Sprite = BlipSprite.PersonalVehicleCar;
                    veh.CurrentBlip.Scale = 0.7f;
                    veh.CurrentBlip.Color = BlipColor.White;
                    veh.CurrentBlip.IsShortRange = true;
                    veh.CurrentBlip.Name = veh.FriendlyName;
                }

                if (tuning) LivelyWorld.RandomTuning(veh, LivelyWorld.IsNightTime(), false);
                //LivelyWorld.ReplacerTime = Game.GameTime + 30000;


                if (LivelyWorld.CanWeUse(ped)) ped.SetIntoVehicle(veh, VehicleSeat.Driver);
                else
                    if (HadDriver)
                {
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - creating driver for it");

                    veh.CreateRandomPedOnSeat(VehicleSeat.Driver);
                    veh.Driver.IsPersistent = false;
                    veh.EngineRunning = true;
                    if (LivelyWorld.IsNightTime()) veh.LightsOn = true;
                }

                if (LivelyWorld.CanWeUse(possibletrailer))
                {
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - arraching trailer to new car");

                    Function.Call(GTA.Native.Hash.ATTACH_VEHICLE_TO_TRAILER, veh, possibletrailer, 10);

                    possibletrailer.IsPersistent = false;
                }
                BlacklistedVehicles.Add(veh);


                veh.IsPersistent = false;
            }

        }
       
    }
    public static bool IsInNamedArea(Entity e, string name)
    {
        string area = name.ToLowerInvariant();
        return GetMapAreaAtCoords(e.Position).ToLowerInvariant() == area || World.GetZoneName(e.Position).ToLowerInvariant() == area || World.GetZoneNameLabel(e.Position).ToLowerInvariant() == area || World.GetStreetName(e.Position).ToLowerInvariant() == area;
    }
    public static Vehicle GetTrailer(Vehicle veh)
    {
        OutputArgument outputArgument = new OutputArgument();
        if (Function.Call<bool>(Hash.GET_VEHICLE_TRAILER_VEHICLE, veh, outputArgument))
        {
            Vehicle trailer = outputArgument.GetResult<Vehicle>();

            if (!CanWeUse(trailer))
            {
                foreach (Vehicle ptrailer in World.GetNearbyVehicles(veh.Position + (veh.ForwardVector * -5), 20f))
                {
                    if ((VehicleHash)ptrailer.Model.Hash == VehicleHash.FreightTrailer) { return ptrailer; }
                    if (ptrailer.Model == "trailers2" || (VehicleHash)ptrailer.Model.Hash == VehicleHash.Trailers2) { return ptrailer; }
                    if (ptrailer.Model == "tanker" || (VehicleHash)ptrailer.Model.Hash == VehicleHash.Tanker) { return ptrailer; }
                }
                if (!CanWeUse(trailer))
                {
                    foreach (Vehicle ptrailer in World.GetNearbyVehicles(veh.Position + (veh.ForwardVector * -5), 20f))
                    {
                        if (Function.Call<bool>(GTA.Native.Hash.IS_VEHICLE_ATTACHED_TO_TRAILER, ptrailer)) { return ptrailer; }
                    }
                }
            }
            else return outputArgument.GetResult<Vehicle>();
        }
        else
        {
            return null;
        }
        return null;
    }

    public static Vehicle GetTrailer(Vehicle veh, Model trailermodel)
    {
        OutputArgument outputArgument = new OutputArgument();
        if (Function.Call<bool>(Hash.GET_VEHICLE_TRAILER_VEHICLE, veh, outputArgument))
        {
            Vehicle trailer = outputArgument.GetResult<Vehicle>();

            if (!CanWeUse(trailer))
            {
                foreach (Vehicle ptrailer in World.GetNearbyVehicles(veh.Position + (veh.ForwardVector * -5), 20f))
                {
                   
                    if (ptrailer.Model == trailermodel || ptrailer.Model.Hash == Game.GenerateHash(trailermodel.ToString())) { return ptrailer; } 
                }
                if (!CanWeUse(trailer))
                {
                    foreach (Vehicle ptrailer in World.GetNearbyVehicles(veh.Position + (veh.ForwardVector * -5), 20f))
                    {
                        if (Function.Call<bool>(GTA.Native.Hash.IS_VEHICLE_ATTACHED_TO_TRAILER, ptrailer) && ptrailer.Model== trailermodel) { return ptrailer; }
                    }
                }
            }
            else return outputArgument.GetResult<Vehicle>();
        }
        else
        {
            return null;
        }
        return null;
    }
    void SpawnCarMeet()
    {
        for (int i = 0; i < 20; i++)
        {

        }
    }

    public static Vector3 GetQuietPlace()
    {
         if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - QuietPlace requested");

        Vector3 pos =Vector3.Zero;
        int patience =0;
        while (patience < 20 && pos==Vector3.Zero)
        {
            patience++;
            Vector3 temp = GenerateSpawnPos(World.GetSafeCoordForPed(Game.Player.Character.Position.Around(150f),false),Nodetype.Offroad,false);
            if (World.GetNearbyPeds(temp, 20f).Length < 2 && GenerateSpawnPos(temp, Nodetype.Road, false).DistanceTo(temp) > 50f)
            {

                return pos=temp;
                //pos = World.GetSafeCoordForPed(temp.Around(20), true);
                //if(pos==Vector3.Zero) pos = temp;
            }
        }

        return pos;
    }

    void SpawnDrugDeal(bool gang)
    {
        Vector3 pos = GetQuietPlace();
        if(pos!=Vector3.Zero)
        {
            DrugDeals.Add(new DrugDeal(pos, gang));
            DrugDealCooldown = Game.GameTime + (1000 * 60 * 5);
        }
        else
        {
            DrugDealCooldown = Game.GameTime + (3000);

        }
    }
    void SpawnTaxiEvent()
    {
         if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - SpawnTaxiEvent()");

        Ped tdriver = null;
        Ped Hitch = null;
        Vehicle vtaxi = null;
        foreach (Vehicle taxi in AllVehicles)
        {
            if (taxi.Model == "taxi" || taxi.Model == "taxi20" || taxi.Model == "taxi21" && CanWeUse(taxi.Driver) && taxi.IsInRangeOf(Game.Player.Character.Position, InteractionRange))
            {
                vtaxi = taxi;
                if (Debug) UI.Notify("got taxi");
                if (CanWeUse(taxi.Driver) && !taxi.Driver.IsPlayer && !taxi.Driver.IsPersistent)
                {
                    if (Debug) UI.Notify("got driver");
                    tdriver = taxi.Driver;

                    if (DoesVehicleHavePassengers(taxi))
                    {
                        foreach (Ped ped in World.GetNearbyPeds(taxi.Position, 5f))//taxi.Position+(taxi.ForwardVector*50)
                        {
                            if (ped.IsInVehicle(taxi) && ped.Handle != taxi.Driver.Handle && ped.IsHuman && !ped.IsPersistent && !ped.IsPlayer)
                            {
                                if (Debug) UI.Notify("got hitch");
                                Hitch = ped;
                                break;
                            }
                        }
                    }
                    else
                    {
                        Vector3 search = taxi.Position + (taxi.ForwardVector * 20) + (taxi.RightVector * 10);
                        foreach (Ped ped in World.GetNearbyPeds(search, 50f))//taxi.Position+(taxi.ForwardVector*50)
                        {
                            if (ped.IsOnFoot && ped.IsAlive && ped.Handle != taxi.Driver.Handle && ped.IsHuman && !ped.IsPersistent && !ped.IsPlayer)
                            {
                                if (Debug) UI.Notify("got hitch");
                                Hitch = ped;
                                break;
                            }
                        }
                    }

                }
            }
        }
        if (CanWeUse(Hitch) && CanWeUse(vtaxi) && CanWeUse(tdriver))
        {
            Taxis.Add(new TaxiEvent(Hitch, tdriver, vtaxi));
            TaxigCooldown = Game.GameTime + 50000;

        }
    }
    void ResprayTruck(Vehicle veh)
    {
         if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - ResprayTruck() "+veh.DisplayName);

        if (CanWeUse(veh))
        {
            if ((veh.Model == "mule" || veh.Model == "mule2"))
            {
                if (veh.IsExtraOn(2)) if(RandomInt(0,10)<=5) veh.PrimaryColor = VehicleColor.WornGreen; else veh.PrimaryColor = VehicleColor.WornWhite;
                else if (veh.IsExtraOn(3)) veh.PrimaryColor = VehicleColor.MetallicFormulaRed;
                else if (veh.IsExtraOn(4)) veh.PrimaryColor = VehicleColor.MetallicGoldenBrown;
                else if (veh.IsExtraOn(6)) veh.PrimaryColor = VehicleColor.MetallicGoldenBrown;
                else if (veh.IsExtraOn(7)) veh.PrimaryColor = VehicleColor.BrushedGold;
                if (Debug) UI.Notify("~b~resprayed Mule to "+veh.PrimaryColor.ToString());

            }

            if (veh.Model == "pounder")
            {
                if (veh.IsExtraOn(1)) veh.PrimaryColor = VehicleColor.MetallicFrostWhite;
                else if (veh.IsExtraOn(2)) veh.PrimaryColor = VehicleColor.MetallicRaceYellow;
                if (Debug) UI.Notify("~b~resprayed Pounder to " + veh.PrimaryColor.ToString());

            }
            if (veh.Model == "benson")
            {

                if (veh.IsExtraOn(1)) veh.PrimaryColor = VehicleColor.MetallicGoldenBrown;
                else if (veh.IsExtraOn(2)) veh.PrimaryColor = VehicleColor.MetallicBlueSilver;
                else if (veh.IsExtraOn(3)) veh.PrimaryColor = VehicleColor.MetallicBlueSilver;
                else if (veh.IsExtraOn(4)) veh.PrimaryColor = VehicleColor.PoliceCarBlue;
                else if (veh.IsExtraOn(5)) veh.PrimaryColor = VehicleColor.MetallicGreen;
                else if (veh.IsExtraOn(6)) veh.PrimaryColor = VehicleColor.MetallicFrostWhite;
                else if (veh.IsExtraOn(7)) veh.PrimaryColor = VehicleColor.MetallicFrostWhite;
                if (Debug) UI.Notify("~b~Resprayed Benson to " + veh.PrimaryColor.ToString());

            }
            if (veh.Model == "packer" || veh.Model == "hauler" || veh.Model == "phantom" || veh.Model=="roadkiller")
            {

                if (Debug) UI.Notify("found " + veh.FriendlyName);
                if (Function.Call<bool>(Hash.IS_VEHICLE_ATTACHED_TO_TRAILER, veh))
                {
                    if (Debug) UI.Notify("has trailer");
                    Vehicle vehtrailer = null;

                    vehtrailer = GetTrailer(veh);
                    if (!CanWeUse(vehtrailer))
                        foreach (Vehicle ptrailer in World.GetNearbyVehicles(veh.Position + (veh.ForwardVector * -5), 20f))
                        {
                            if (ptrailer.Model == "trailers2" || (VehicleHash)ptrailer.Model.Hash == VehicleHash.Trailers2) { vehtrailer = ptrailer; return; }
                            if (ptrailer.Model == "tanker" || (VehicleHash)ptrailer.Model.Hash == VehicleHash.Tanker) { vehtrailer = ptrailer; return; }
                        }

                    if (CanWeUse(vehtrailer))
                    {
                        if (Debug) UI.Notify("correct trailer model");
                        if ((VehicleHash)vehtrailer.Model.Hash == VehicleHash.Tanker || (VehicleHash)vehtrailer.Model.Hash == VehicleHash.Tanker2) veh.PrimaryColor = VehicleColor.Orange;
                        if (vehtrailer.LiveryCount > 0)
                        {
                            if (Debug) UI.Notify("~g~changed color");
                            switch (vehtrailer.Livery)
                            {
                                case 0:
                                    {
                                        if (Debug) UI.Notify("~g~gold");
                                        veh.PrimaryColor = VehicleColor.PureGold;
                                        break;
                                    }
                                case 2:
                                    {
                                        if (Debug) UI.Notify("~g~yellow");
                                        veh.PrimaryColor = VehicleColor.MetallicTaxiYellow;

                                        break;
                                    }
                                case 3:
                                    {
                                        if (Debug) UI.Notify("~g~red");

                                        veh.PrimaryColor = VehicleColor.MetallicBlazeRed;
                                        break;
                                    }
                            }
                        }
                    }
                }
            }
        }
    }



    int PedRushingCooldown = 0;
    int TaxigCooldown = 0;
    int CarInteractionCooldown = 0;
    int EmergencyRushingCooldown = 0;

    void Scenarios()
    {

        if (Debug) UI.Notify("AmbientSmallEvents()");


         if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Scenarios() ");

        //Interaction Events
        int randomselector = RandomInt(1, 5);

        switch (randomselector)
        {

            case 1: //PedRushing
                {
                    if (Debug) UI.Notify("Trying PedRushing");
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - PedRushing");

                    if (!DisabledEvents.Contains(EventType.DriverRushing))
                    {
                        if ( Game.GameTime > PedRushingCooldown)
                        {

                        foreach (Vehicle veh in AllVehicles)
                        {
                            if (CanWeUse(veh) && veh.EngineRunning && !isCopVehicleRange(veh.Position, 5f) && !BlacklistedVehicles.Contains(veh) && !veh.IsPersistent && !LastDriverIsPed(veh, Game.Player.Character))
                            {
                                if (CanWeUse(veh.Driver) && !veh.Driver.IsPersistent && !veh.Driver.IsInCombat)
                                {
                                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - correct");

                                    if (Debug) UI.Notify("~b~Driver rushing triggered");
                                    Ped ped = veh.Driver;
                                    ped.Task.ClearAll();
                                    ped.MaxDrivingSpeed = 120f;
                                    ped.AlwaysKeepTask = true;
                                    Function.Call(Hash.TASK_VEHICLE_DRIVE_WANDER, ped, veh, 60f, 1 + 2 + 4 + 8 + 16 + 32);

                                    if (DebugBlips && !ped.CurrentBlip.Exists())
                                    {
                                        ped.AddBlip();
                                        ped.CurrentBlip.Color = BlipColor.Yellow;
                                        ped.CurrentBlip.Scale = 0.7f;
                                        ped.CurrentBlip.IsShortRange = true;
                                    }
                                    PedRushingCooldown = Game.GameTime + (RandomInt(40, 120) * 1000);
                                    //BlacklistedEvents.Add(EventType.DriverRushing);
                                    BlacklistedVehicles.Add(veh);
                                    return;
                                }
                            }
                        }
                        }
                        if (Debug) UI.Notify("~o~PedRushing is on cooldown (" + (Game.GameTime - PedRushingCooldown) / 1000 + "s)");
                    }
                    else if (Debug) UI.Notify("~o~PedRushing event is disabled."); 
                    break;
                }
            case 2: //Taxi
                {
                    if (Debug) UI.Notify("Trying Taxi");
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Taxi scenario");
                    if (!DisabledEvents.Contains(EventType.Taxi))
                    {
                        if (TaxigCooldown < Game.GameTime)
                        {
                            SpawnTaxiEvent();
                        }
                        else
                        {
                            if (Debug) UI.Notify("~o~Taxi is on cooldown (" + (Game.GameTime - TaxigCooldown) / 1000 + "s)");
                        }
                    }
                    else if (Debug) UI.Notify("~o~Taxi event is disabled.");
                    break;
                }
            case 3: //DrivingOut / Interaction
                {
                    if (Debug) UI.Notify("Trying car interaction");
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - car interaction");
                    if (!DisabledEvents.Contains(EventType.VehicleInteraction))
                    {
                        if (CarInteractionCooldown < Game.GameTime)
                        {
                            foreach (Vehicle veh in AllVehicles)
                            {
                                if (CanWeUse(veh) && veh.IsAlive && !veh.EngineRunning && veh.IsStopped && !CanWeUse(veh.Driver) && veh.ClassType != VehicleClass.Emergency && veh.IsInRangeOf(Game.Player.Character.Position, InteractionRange) && 
                                    !veh.IsPersistent && !LastDriverIsPed(veh,Game.Player.Character) && !BlacklistedVehicles.Contains(veh))
                                {
                                    if (RandomInt(0, 10) <= 5) //Spawn Interaction
                                    {
                                        if (veh.Model.IsCar && !WouldPlayerNoticeChangesHere(veh.Position))
                                        {
                                            Ped ped = World.CreateRandomPed(veh.Position.Around(10));
                                            TemporalPersistence.Add(ped);

                                            ped.AlwaysKeepTask = true;
                                            veh.IsPersistent = true;
                                            veh.LockStatus = VehicleLockStatus.Unlocked;
                                            veh.NeedsToBeHotwired = false;
                                            TemporalPersistence.Add(veh);

                                            ped.SetNoCollision(veh, true);
                                            veh.SetNoCollision(ped, true);

                                            if (CanWeUse(veh) && CanWeUse(ped))
                                            {
                                                BlacklistedVehicles.Add(veh);
                                                CarInteractionCooldown = Game.GameTime + 30000;//BlacklistedEvents.Add(EventType.VehicleInteraction);
                                                Script.Wait(500);
                                                SpawnCarInteraction(veh, ped);
                                                return;
                                            }
                                        }
                                    }
                                    else if (veh.Model.IsCar) //Driving out
                                    {
                                        foreach (Ped ped in World.GetNearbyPeds(veh.Position, 30f))
                                        {
                                            if (ped.IsHuman && ped.IsAlive && !ped.IsPersistent && !ped.IsPlayer && ped.IsOnFoot && !ped.IsInCombat)
                                            {
                                                if (Debug) UI.Notify("~b~Ped driving out triggered");
                                                ped.AlwaysKeepTask = true;
                                                veh.LockStatus = VehicleLockStatus.Unlocked;
                                                veh.NeedsToBeHotwired = false;
                                                TaskSequence seq = new TaskSequence();
                                                Function.Call(Hash.TASK_ENTER_VEHICLE, 0, veh, 20000, -1, 1f, 1, 0);
                                                Function.Call(Hash.TASK_PAUSE, 0, RandomInt(2, 4) * 1000);
                                                Function.Call(Hash.TASK_VEHICLE_DRIVE_WANDER, 0, veh, 30f, 1 + 2 + 4 + 8 + 16 + 32);
                                                seq.Close();
                                                ped.Task.PerformSequence(seq);
                                                seq.Dispose();
                                                ped.BlockPermanentEvents = false;

                                                if (DebugBlips && !ped.CurrentBlip.Exists())
                                                {
                                                    ped.AddBlip();
                                                    ped.CurrentBlip.Color = BlipColor.Green;
                                                    ped.CurrentBlip.Scale = 0.7f;
                                                    ped.CurrentBlip.IsShortRange = true;
                                                    ped.CurrentBlip.Name = "Car interaction (driving out)";
                                                }
                                                CarInteractionCooldown = Game.GameTime + 3000;// BlacklistedEvents.Add(EventType.PedDrivingOut);
                                                BlacklistedVehicles.Add(veh);
                                                return;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (Debug) UI.Notify("~o~Car interactions are on cooldown (" + (Game.GameTime - CarInteractionCooldown) / 1000 + "s)");
                    }
                    else if (Debug) UI.Notify("~o~Car interactions are disabled.");
                    break;
                }
            case 4: //Emergency
                {
                    if (Debug) UI.Notify("Trying emergency");
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - emergency scenario");

                    if (EmergencyRushingCooldown>Game.GameTime)
                    {
                        if (Debug) UI.Notify("~o~EmergencyRushing is on cooldown (" + (Game.GameTime - EmergencyRushingCooldown) / 1000 + "s)");
                        return;
                    }
                    if (!DisabledEvents.Contains(EventType.EmergencyRushing))
                    {
                        foreach (Vehicle veh in AllVehicles)
                        {
                            if (isCopVehicleRange(veh.Position, 1f) && !BlacklistedVehicles.Contains(veh) && !veh.IsPersistent && !LastDriverIsPed(veh, Game.Player.Character)) //Cop events
                            {
                                if (!veh.EngineRunning && veh.IsStopped)
                                {
                                    foreach (Ped ped in World.GetNearbyPeds(veh.Position, 60f))
                                    {
                                        if (ped.IsHuman && ped.IsAlive && !ped.IsPersistent && !ped.IsPlayer && isCopInRange(ped.Position, 1f) && ped.IsOnFoot && !ped.IsInCombat)
                                        {
                                            if (DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - correct");

                                            if (Debug) UI.Notify("~b~Cop driving out triggered");
                                            ped.AlwaysKeepTask = true;
                                            veh.LockStatus = VehicleLockStatus.Unlocked;
                                            veh.NeedsToBeHotwired = false;
                                            veh.SirenActive = true;

                                            Function.Call(Hash.TASK_VEHICLE_DRIVE_WANDER, ped, veh, 60f, 1 + 2 + 4 + 8 + 16 + 32);
                                            if (DebugBlips && !ped.CurrentBlip.Exists())
                                            {
                                                ped.AddBlip();
                                                ped.CurrentBlip.Color = BlipColor.Blue;
                                                ped.CurrentBlip.IsFlashing = true;
                                                ped.CurrentBlip.Scale = 0.7f;
                                                ped.CurrentBlip.IsShortRange = true;
                                            }
                                            EmergencyRushingCooldown = Game.GameTime + 50000;
                                            BlacklistedVehicles.Add(veh);
                                            return;
                                        }
                                    }
                                }
                                else
                                {
                                    if (CanWeUse(veh.Driver) && !veh.Driver.IsPlayer && !veh.Driver.IsInCombat)
                                    {
                                        if (isCopInRange(veh.Driver.Position, 1f))
                                        {
                                            if (DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - correct");

                                            if (Debug) UI.Notify("~b~Cop rushing to emergency triggered");
                                            Ped ped = veh.Driver;
                                            ped.AlwaysKeepTask = true;
                                            veh.SirenActive = true;
                                            ped.MaxDrivingSpeed = 120f;
                                            Function.Call(Hash.TASK_VEHICLE_DRIVE_WANDER, ped, veh, 60f, 1 + 2 + 4 + 8 + 16 + 32);

                                            if (DebugBlips && !ped.CurrentBlip.Exists())
                                            {
                                                ped.AddBlip();
                                                ped.CurrentBlip.Color = BlipColor.Blue;
                                                ped.CurrentBlip.IsFlashing = true;
                                                ped.CurrentBlip.Scale = 0.7f;
                                                ped.CurrentBlip.IsShortRange = true;
                                            }
                                            EmergencyRushingCooldown = Game.GameTime + 50000;
                                            BlacklistedVehicles.Add(veh);
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (Debug) UI.Notify("~o~EmergencyRushing is disabled.");
                    break;
                }
            case 5:
                {

                    break;
                }
        }
    }

    public static bool LastDriverIsPed(Vehicle veh, Ped p)
    {
        if (!CanWeUse(veh)) return false;

        Ped ped = Function.Call<Ped>(Hash.GET_LAST_PED_IN_VEHICLE_SEAT, veh, -1);
        if(CanWeUse(ped) && CanWeUse(p))
        {
            if (ped.Handle == p.Handle) return true;
        }
        return false;
    }
    public static bool CarCanSeePos(Vehicle veh, Vector3 pos, int height_offset)
    {
        //if (veh.Position.DistanceTo(pos) < 50f) return true;
        if (veh.Position.DistanceTo(pos) < 100f)
        {
            RaycastResult raycast = World.Raycast(veh.Position + new Vector3(0, 0, height_offset), pos + new Vector3(0, 0, height_offset), IntersectOptions.Map);

            if (!raycast.DitHitAnything) return true;
        }
        return false;
    }

    void OnKeyDown(object sender, KeyEventArgs e)
    {

    }
    void OnKeyUp(object sender, KeyEventArgs e)
    {

    }

    void CauseAccident()
    {
        foreach (Vehicle veh in World.GetNearbyVehicles(PlayerPed().Position, 20f))
        {
            if (CanWeUse(veh) && veh.Speed > 5f && CanWeUse(veh.GetPedOnSeat(VehicleSeat.Driver)) && veh.Speed > 20f && veh.GetPedOnSeat(VehicleSeat.Driver).Handle != PlayerPed().Handle)
            {
                if (Debug) UI.Notify("Causing accident to " + veh.FriendlyName);
                veh.ApplyForceRelative(new Vector3(0f, 2f, 0f), new Vector3(0f, 0f, 1f));
                Function.Call(Hash.SET_VEHICLE_REDUCE_GRIP, veh, true);
                Script.Wait(500);
                Function.Call(Hash.SET_VEHICLE_REDUCE_GRIP, veh, false);
                break;
            }
        }
    }
    bool IsRaining()
    {
         if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - IsRaining()");

        int weather = Function.Call<int>(GTA.Native.Hash._0x564B884A05EC45A3); //get current weather hash
        switch (weather)
        {
            case (int)WeatherType.BLIZZARD:
                {
                    return true;
                }
            case (int)WeatherType.CLEARING:
                {
                    return true;
                }
            case (int)WeatherType.FOGGY:
                {
                    return true;
                }
            case (int)WeatherType.RAIN:
                {
                    return true;
                }
            case (int)WeatherType.NEUTRAL:
                {
                    return true;
                }
            case (int)WeatherType.THUNDER:
                {
                    return true;
                }
            case (int)WeatherType.LIGHT_SNOW:
                {
                    return true;
                }
            case (int)WeatherType.SNOW:
                {
                    return true;
                }
            case (int)WeatherType.X_MAS:
                {
                    return true;
                }
        }
        return false;
    }
    public static bool IsNightTime()
    {        

        int hour = Function.Call<int>(Hash.GET_CLOCK_HOURS);
        return (hour > 20 || hour < 7);
    }


    int GangDrivebyCooldown = Game.GameTime+40000;
    int HunterCooldown = Game.GameTime + 40000;
    int SpawnEmegencyRushingCooldown = Game.GameTime + 30000;
    int DrugDealCooldown = Game.GameTime + 120000;
    int AnimalTrophyCooldown = Game.GameTime + 4000;
    int RacerCooldown = Game.GameTime + 300000;
    int BennysCooldown = Game.GameTime + 5000;

    void HandleSpawnerEvents()
    {
         if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - HandleSpawnerEvents()");

        if (Debug) UI.Notify("~b~HandleSpawnerEvents()");
        if (RandomInt(0, 100) >= EventFrecuency)
        {
            if (Debug) UI.Notify("~b~dice says no spawner now");
            return;
        }
        else if (Debug) UI.Notify("~g~dice says events will spawn");

        int eventspawnerint = RandomInt(0, 5);
        switch (eventspawnerint)
        {
            case 0:
                {
                    if (Debug) UI.Notify("~b~dice says driveby");
                    if (DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Driveby");

                    //DriveBy
                    if (!DisabledEvents.Contains(EventType.GangDriveby))
                    {
                        if (!IsNightTime() && GangDrivebyCooldown < Game.GameTime && Game.Player.WantedLevel == 0)
                        {
                            switch (World.GetZoneNameLabel(Game.Player.Character.Position))
                            {
                                case "RANCHO":
                                case "CYPRE": //Vagos territory
                                    {
                                        BlacklistedEvents.Add(EventType.GangDriveby);
                                        Ped ped = null;
                                        foreach (Ped p in AllPeds) if (CanWeUse(p) && p.IsAlive && p.IsHuman  && p.IsOnFoot && p.IsInRangeOf(Game.Player.Character.Position, InteractionRange)) { ped = p; break; }
                                        if (CanWeUse(ped)) if (RandomInt(0, 10) <= 5) SpawnGangDriveBy(Gang.Ballas, ped); else SpawnGangDriveBy(Gang.Families, ped);
                                        break;
                                    }
                                case "DAVIS": //Ballas territory
                                    {
                                        BlacklistedEvents.Add(EventType.GangDriveby);
                                        Ped ped = null;
                                        foreach (Ped p in AllPeds) if (CanWeUse(p) && p.IsAlive && p.IsHuman && p.IsOnFoot && p.IsInRangeOf(Game.Player.Character.Position, InteractionRange)) { ped = p; break; }
                                        if (CanWeUse(ped)) if (RandomInt(0, 10) <= 5) SpawnGangDriveBy(Gang.Vagos, ped); else SpawnGangDriveBy(Gang.Families, ped);
                                        break;
                                    }
                                case "CHAMH": //Families territory
                                    {
                                        BlacklistedEvents.Add(EventType.GangDriveby);
                                        Ped ped = null;
                                        foreach (Ped p in AllPeds) if (CanWeUse(p) && p.IsAlive && p.IsHuman && p.IsOnFoot && p.IsInRangeOf(Game.Player.Character.Position, InteractionRange)) { ped = p; break; }
                                        if (CanWeUse(ped)) if (RandomInt(0, 10) <= 5) SpawnGangDriveBy(Gang.Ballas, ped); else SpawnGangDriveBy(Gang.Vagos, ped);
                                        break;
                                    }
                                default:
                                    {
                                        if (Debug) UI.Notify("Player is not in a valid gang activity area.");
                                        break;
                                    }
                            }
                        }
                    }
                    else if (Debug) UI.Notify("~o~Gang Activity is disabled.");
                    break;
                }
            case 1:
                {
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Hunter/trophy");

                    if (Debug) UI.Notify("~b~dice says hunter/trophy");

                    //Hunter && Animal trophy
                    if (!DisabledEvents.Contains(EventType.Hunter) && HunterCooldown < Game.GameTime)
                    {
                        if (Hunters.Count == 0 &&
                        (IsInNamedArea(Game.Player.Character, "CANNY") || IsInNamedArea(Game.Player.Character, "MTJOSE") ||
                        IsInNamedArea(Game.Player.Character, "DESRT") ||
                        IsInNamedArea(Game.Player.Character, "CMSW") ||
                        IsInNamedArea(Game.Player.Character, "ZANCUDO") ||
                        IsInNamedArea(Game.Player.Character, "LAGO") ||
                        IsInNamedArea(Game.Player.Character, "GREATC") ||
                        IsInNamedArea(Game.Player.Character, "PALHIGH") ||
                        IsInNamedArea(Game.Player.Character, "CCREAK") ||
                        IsInNamedArea(Game.Player.Character, "MTCHIL")))
                        {
                            if (Debug) UI.Notify("~b~Spawning hunter");
                            Vector3 pos = World.GetSafeCoordForPed(Game.Player.Character.Position.Around(100), false); //GenerateSpawnPos(Game.Player.Character.Position.Around(50),Nodetype.Offroad,false)
                            if (pos.DistanceTo(Game.Player.Character.Position) < 300)
                            {
                                //if (GenerateSpawnPos(pos, Nodetype.Road, false).DistanceTo(pos) < 30) pos = GenerateSpawnPos(pos, Nodetype.Offroad, false);
                                Hunters.Add(new Hunter(pos));
                                HunterCooldown = Game.GameTime + (1000 * 60 * RandomInt(1, 6));
                            }
                        }
                    }

                    if (!DisabledEvents.Contains(EventType.AnimalTrophy) && AnimalTrophyCooldown < Game.GameTime && (IsInNamedArea(Game.Player.Character, "ALAMO") || IsInNamedArea(Game.Player.Character, "PALETO") || IsInNamedArea(Game.Player.Character, "SANDY")))
                    {
                        if (Debug) UI.Notify("~b~Spawning trophy");
                        SpawnAnimalTrophy();
                    }
                    break;
                }
            case 2:
                {
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Deal");

                    if (Debug) UI.Notify("~b~dice says Deal");

                    //Deals
                    if (!DisabledEvents.Contains(EventType.Deal) && DrugDealCooldown < Game.GameTime)
                    {
                        NoEventsHereFar = Game.Player.Character.Position;
                        SpawnDrugDeal(IsInNamedArea(Game.Player.Character, "desrt"));
                    }
                    break;
                }
            case 3:
                {

                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Racer");
                    if (Debug) UI.Notify("~b~dice says Racer");

                    //Racers
                    int BaseProb = 3;
                    if (IsNightTime()) BaseProb = BaseProb + 2;

                    if (!DisabledEvents.Contains(EventType.Racer) && RacerCooldown < Game.GameTime && Racecars.Count > 0 && IsInNamedArea(Game.Player.Character, "city") && RandomInt(0, 10) <= BaseProb)
                    {
                        Model model = Racecars[RandomInt(0, Racecars.Count - 1)];
                        if (model.IsValid)
                        {
                            Vehicle veh = World.CreateVehicle(model, FindHiddenSpot(50, true), RandomInt(0, 360));
                            if (CanWeUse(veh))
                            {
                                RandomTuning(veh, IsNightTime(), false);
                                Ped ped = veh.CreateRandomPedOnSeat(VehicleSeat.Driver);
                                ped.AlwaysKeepTask = true;
                                MoveEntitytoNearestRoad(veh,true,true);
                                Function.Call(Hash.TASK_VEHICLE_DRIVE_WANDER, ped, veh, 30f, 4 + 8 + 16 + 32);
                                if (!veh.CurrentBlip.Exists() && DebugBlips)
                                {
                                    veh.AddBlip();
                                    veh.CurrentBlip.Sprite = BlipSprite.PersonalVehicleCar;
                                    veh.CurrentBlip.Scale = 0.7f;
                                    veh.CurrentBlip.Color = BlipColor.Yellow;
                                    veh.CurrentBlip.IsShortRange = true;
                                    veh.CurrentBlip.Name = "Racer";
                                }
                                if (Debug) UI.Notify("Racing car spawned");

                                //ped.IsPersistent = false;
                                //veh.IsPersistent = false;
                                TemporalPersistence.Add(ped);
                                TemporalPersistence.Add(veh);
                                BlacklistedEvents.Add(EventType.Racer);
                                //SpawnerEventCooldownTime = SpawnerEventCooldownTime + 10000;

                                RacerCooldown = Game.GameTime + (1000 * 60 * 10);
                                return;
                            }
                        }
                    }
                    break;
                }
            case 4:
                {
                     if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Bennys");

                    if (Debug) UI.Notify("~b~dice says bennys");

                    //Benny's Motorworks
                    if (!DisabledEvents.Contains(EventType.Bennys) && BennysCooldown < Game.GameTime && Bennys.Count > 0 && Game.Player.Character.IsInRangeOf(BennysMotorworks, 200f) && !CanPedSeePos(Game.Player.Character, BennysMotorworks, true))
                    {
                        Model model = Bennys[RandomInt(0, Bennys.Count - 1)];
                        if (model.IsValid)
                        {
                            Vehicle veh = World.CreateVehicle(Bennys[RandomInt(0, Bennys.Count)], BennysMotorworks, 0);
                            if (CanWeUse(veh))
                            {
                                RandomTuning(veh, IsNightTime(), false);
                                Ped ped = veh.CreateRandomPedOnSeat(VehicleSeat.Driver);
                                ped.AlwaysKeepTask = true;

                                Function.Call(Hash.TASK_VEHICLE_DRIVE_WANDER, ped, veh, 15f, 1 + 2 + 4 + 8 + 16 + 32);
                                if (!veh.CurrentBlip.Exists() && DebugBlips)
                                {
                                    veh.AddBlip();
                                    veh.CurrentBlip.Sprite = BlipSprite.PersonalVehicleCar;
                                    veh.CurrentBlip.Scale = 0.7f;
                                    veh.CurrentBlip.Color = BlipColor.Green;
                                    veh.CurrentBlip.IsShortRange = true;
                                    veh.CurrentBlip.Name = "Custom Vehicle";
                                }
                                if (Debug) UI.Notify("~b~Benny's car spawned");

                                ped.IsPersistent = false;
                                veh.IsPersistent = false;
                                SpawnerEventCooldownTime = SpawnerEventCooldownTime + 20000;

                                BennysCooldown = Game.GameTime + (1000 * 60 * 5);
                                return;
                            }
                        }
                    }
                    break;
                }
            case 5:
                {

                    break;
                }
        }
                                  
        int Random = RandomInt(0, 100);
        int accident = AccidentEventProb;
        int criminal = CriminalEventProb;
        int tow = 20;

        if (IsRaining())
        {
            accident = +30;
            tow = +20;
        }
        if (IsNightTime()) criminal = +30;


        criminal += RandomInt((criminal * -1) / 2, criminal / 2);
        accident += RandomInt((accident * -1) / 2, accident / 2);
        accident += RandomInt((tow * -1) / 2, tow / 2);


        if (tow > Random )
        {
             if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - SpawnTow()");

            SpawnerEventCooldownTime = Game.GameTime + 20000;
            SpawnTow();
            return;
        }
        if (criminal > Random)
        {
             if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - CreateCriminalEvent()");

            SpawnerEventCooldownTime = Game.GameTime + 30000;
            CreateCriminalEvent();
            return;
        }
        if (accident > Random)
        {
             if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - CreateAccidentEvent()");

            SpawnerEventCooldownTime = Game.GameTime + 30000;
            CreateAccidentEvent();
            return;
        }

        if (Debug) UI.Notify("Requirement: " + Random + "~n~criminal: " + criminal + "~n~accident: " + accident + "~n~Tow:" + tow);
    }

    void CreateCriminalEvent()
    {
        if(Debug) UI.Notify("CreateCriminalEvent()");
        if(RandomInt(0,10)<= 5)
        {
            if (Debug) UI.Notify("Carjacker spawned.");

            CarjackerEnabled = true;
        }
        else
        {
            if (Debug) UI.Notify("[Event] Busy copcar spawned.");
            //SpawnChase(FindHiddenSpot(50,true),false);
            if (!BlacklistedEvents.Contains(EventType.EmergencyRushing))
            {
                SpawnEmergencyVehicle(EmergencyType.POLICE);
                BlacklistedEvents.Add(EventType.EmergencyRushing);
            }
        }

    }

    Vector3 GetclosestMajorVehNode(Vector3 reference)
    {
        Vector3 node = reference;

        OutputArgument outArgA = new OutputArgument();
        OutputArgument outArgB = new OutputArgument();


        if (Function.Call<bool>(Hash.GET_CLOSEST_MAJOR_VEHICLE_NODE, reference.X, reference.Y, reference.Z, outArgA, 3.0f, 0))
        {
            node = outArgA.GetResult<Vector3>(); //Get position
        }
        return node;
    }


    void SpawnChase(Vector3 pos, bool big)
    {
        if (Debug) UI.Notify("chase spawned");
        Vehicle criminalveh;
        Ped criminalped;

        Vehicle copveh;
        Ped copped;

        if (big)
        {

        }
        else
        {
            criminalveh = World.CreateVehicle(RandomNormalVehicle(), FindHiddenSpot(50, true), 0f);
            criminalped = Function.Call<Ped>(Hash.CREATE_RANDOM_PED_AS_DRIVER, criminalveh, true);
            PreparePed(criminalped, true);
            Function.Call(GTA.Native.Hash.TASK_VEHICLE_DRIVE_WANDER, criminalped, criminalveh, 90f, (4 + 16 + 32 + 262144));
            criminalped.RelationshipGroup = CriminalRelGroup;
            MoveEntitytoNearestRoad(criminalveh);

            copveh = World.CreateVehicle(GetRandomPoliceVehicle(), criminalveh.Position + (criminalveh.ForwardVector * -5), criminalveh.Heading);
            copped = Function.Call<Ped>(Hash.CREATE_RANDOM_PED_AS_DRIVER, copveh, true);
            copveh.SirenActive = true;
            PreparePed(copped, false);
            copped.Task.VehicleChase(criminalped);
            copped.Weapons.Give(WeaponHash.Pistol, -1, true, true);
            Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, copped, 2, false);
            copped.RelationshipGroup = Function.Call<int>(GTA.Native.Hash.GET_HASH_KEY, "COP");
            Function.Call(Hash.SET_VEHICLE_FORWARD_SPEED, criminalveh, 10f);
            Function.Call(Hash.SET_VEHICLE_FORWARD_SPEED, copveh, 10f);

            criminalped.Task.FleeFrom(copped);

            copveh.AddBlip();


            Script.Wait(5000);
            copveh.IsPersistent = false;
            criminalveh.IsPersistent = false;
            copped.IsPersistent = false;
            criminalped.IsPersistent = false;
        }
    }



    Vector3 FindHiddenSpot(float distance, bool road)
    {
        Vector3 spot = World.GetNextPositionOnStreet(PlayerPed().Position.Around(distance));

        if (road)
        {
            for (int i = 0; i < 20; i++)
            {
                spot = World.GetNextPositionOnStreet(PlayerPed().Position.Around(distance + (i * 2)));
                RaycastResult raycast = World.Raycast(PlayerPed().Position + new Vector3(0, 0, 4), spot + new Vector3(0, 0, 4), IntersectOptions.Map);
                if (raycast.DitHitAnything || PlayerPed().Position.DistanceTo(spot) > 100f)
                {
                    if (Debug) UI.Notify("[HiddenSpot] Found place, " + i + "º try");
                    break;
                }
                else if (i == 19 && Debug) UI.Notify("[HiddenSpot] ~r~Didn't find appropiate place");
            }
            return spot;
        }
        else
        {
            for (int i = 0; i < 20; i++)
            {
                spot = World.GetSafeCoordForPed(PlayerPed().Position.Around(distance));
                RaycastResult raycast = World.Raycast(PlayerPed().Position, spot + new Vector3(0, 0, 1), IntersectOptions.Map);
                if (raycast.DitHitAnything || PlayerPed().Position.DistanceTo(spot) > 100f)
                {
                    if (Debug) UI.Notify("[HiddenSpot] Found place, " + i + "º try");
                    break;
                }
                else if (i == 19 && Debug) UI.Notify("[HiddenSpot] ~r~Didn't find appropiate place");
            }
            return spot;
        }
    }

    void CreateAccidentEvent()
    {
        if (!BlacklistedEvents.Contains(EventType.EmergencyRushing))
        {
            int type = RandomInt(1, 3);
            switch (type)
            {
                case 1: SpawnEmergencyVehicle(EmergencyType.FIRETRUCK); break;
                case 2: SpawnEmergencyVehicle(EmergencyType.AMBULANCE); break;
                case 3: CauseAccident(); break;
                case 4: CauseAccident(); break;
                case 5: CauseAccident(); break;
            }
            BlacklistedEvents.Add(EventType.EmergencyRushing);
        }

    }


   public static void MoveEntitytoNearestRoad(Entity E)
    {
        if (CanWeUse(E))
        {
            OutputArgument outArgA = new OutputArgument();
            OutputArgument outArgB = new OutputArgument();
            if (Function.Call<bool>(Hash.GET_CLOSEST_VEHICLE_NODE_WITH_HEADING, E.Position.X, E.Position.Y, E.Position.Z, outArgA, outArgB, 0, 1077936128, 0))
            {
                E.Heading = outArgB.GetResult<float>(); //getting heading
            }

            if (Function.Call<bool>(Hash.GET_CLOSEST_MAJOR_VEHICLE_NODE, E.Position.X, E.Position.Y, E.Position.Z, outArgA, outArgB, 3.0f, 0))
            {
                E.Position = outArgA.GetResult<Vector3>(); //Get position
            }
        }
    }

    static public void MoveEntitytoNearestRoad(Entity E, bool move, bool heading)
    {
        OutputArgument outArgA = new OutputArgument();
        OutputArgument outArgB = new OutputArgument();


        if (Function.Call<bool>(Hash.GET_CLOSEST_VEHICLE_NODE_WITH_HEADING, E.Position.X, E.Position.Y, E.Position.Z, outArgA, outArgB, 1, 1077936128, 0))
        {
           if(move) E.Position = outArgA.GetResult<Vector3>(); //Get position
            if(heading) E.Heading = outArgB.GetResult<float>(); //getting heading
        }
    }
    Ped PlayerPed()
    {
        return Game.Player.Character;
    }

    static public bool CanWeUse(Entity entity)
    {
        return entity != null && entity.Exists();
    }


    string RandomNormalVehicle()
    {
        return NormalVehicleModel[RandomInt(0, NormalVehicleModel.Count - 1)].ToString();
    }

    string RandomVehInMemory()
    {


        OutputArgument outArgA = new OutputArgument();
        OutputArgument outArgB = new OutputArgument();

        Function.Call(Hash.GET_RANDOM_VEHICLE_MODEL_IN_MEMORY, true, outArgA, outArgB);

        return outArgA.GetResult<string>();
    }


    VehicleHash GetRandomPoliceVehicle()
    {
        if (PlayerPed().IsInRangeOf(CityCenter, 3000))
        {
            switch (RandomInt(0, 3))
            {
                case 0:
                    {
                        return VehicleHash.Police;
                    }
                case 1:
                    {
                        return VehicleHash.Police2;
                    }
                case 2:
                    {
                        return VehicleHash.Police3;
                    }
                case 3:
                    {
                        return VehicleHash.Police4;
                    }
            }
        }
        else
        {
            switch (RandomInt(1, 2))
            {
                case 1:
                    {
                        return VehicleHash.Sheriff;
                    }
                case 2:
                    {
                        return VehicleHash.Sheriff2;
                    }
            }
        }
        return VehicleHash.Police;
    }

    void SpawnTow()
    {
        if (!BlacklistedEvents.Contains(EventType.Tow))
        {
             if(DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Spawning tow event");

            int patience = 0;
            Vector3 hiddenpos = Vector3.Zero;


            while (patience < 30 && (hiddenpos == Vector3.Zero || !WouldPlayerNoticeChangesHere(hiddenpos)))
            {
                hiddenpos = GenerateSpawnPos(Game.Player.Character.Position.Around(10+(patience*10)), Nodetype.Road, false);
                patience++;
            }
            if (WouldPlayerNoticeChangesHere(hiddenpos) || Game.Player.Character.IsInRangeOf(hiddenpos, 20f))
            {
                if (DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Didn't find any proper hidden position for the tow.");
                return;
            }
                //FindHiddenSpot(100f, true);
            Vehicle tow = null;
            foreach (Vehicle v in AllVehicles) if (v.Model == VehicleHash.TowTruck && !v.IsPersistent && !WouldPlayerNoticeChangesHere(v.Position)) { tow = v; break;}

            if(!CanWeUse(tow)) tow= World.CreateVehicle(VehicleHash.TowTruck, hiddenpos, 0);
            Ped towdriver = tow.Driver;
            
            if(!CanWeUse(towdriver)) towdriver=Function.Call<Ped>(Hash.CREATE_RANDOM_PED_AS_DRIVER, tow, true);

            if (CanWeUse(towdriver) && CanWeUse(tow))
        {
            PreparePed(towdriver, false);

            MoveEntitytoNearestRoad(tow, true,true);

            Script.Wait(500);
            Function.Call(GTA.Native.Hash.TASK_VEHICLE_DRIVE_WANDER, towdriver, tow, 15f, (1 + 24 + 16 + 32 + 262144));

                Model model = GetRandomVehicleHash();
                if (model.Hash == tow.Model.Hash) model = "blista";
            Vehicle towed = World.CreateVehicle(model, tow.Position + (tow.ForwardVector * -8), tow.Heading);
            //towed.Heading = tow.Heading;


            Function.Call(Hash.SET_VEHICLE_FORWARD_SPEED, tow, 4f);
            Function.Call(Hash.SET_VEHICLE_FORWARD_SPEED, towed, 4f);

            Function.Call(Hash.ATTACH_VEHICLE_TO_TOW_TRUCK, tow, towed, false, 0, 0, 0);
            Function.Call(Hash._SET_TOW_TRUCK_CRANE_RAISED, tow, 1f);

            if (DebugBlips && !tow.CurrentBlip.Exists())
            {
                tow.AddBlip();
                //tow.CurrentBlip.Color = BlipColor.Green;
                tow.CurrentBlip.Sprite = BlipSprite.TowTruck;
                tow.CurrentBlip.Scale = 0.7f;
                    tow.CurrentBlip.IsShortRange = true;

                }
                tow.EngineRunning = true;
            tow.SirenActive = true;
            tow.IsPersistent = false;
            towdriver.IsPersistent = false;
            towed.IsPersistent = false;

            if (Debug) UI.Notify("Tow + vehicle spawned");
                BlacklistedVehicles.Add(tow);
                BlacklistedVehicles.Add(towed);
            }
        else
        {
            if (Debug) UI.Notify("Tow + vehicle failed to spawn");

        }
            BlacklistedEvents.Add(EventType.Tow);

        }
    }

    public static Model GetRandomVehicleHash()
    {
        foreach (Vehicle veh in World.GetAllVehicles())
        {
            if (veh.Model.IsCar) return veh.Model;
        }
        return "blista";
    }

    void SpawnEmergencyVehicle(EmergencyType E)
    {


        int type = (int)VehicleHash.Police;
        switch (E)
        {
            case EmergencyType.AMBULANCE:
                {
                    type = (int)VehicleHash.Ambulance;
                    break;
                }
            case EmergencyType.FIRETRUCK:
                {
                    type = (int)VehicleHash.FireTruck;
                    break;
                }
            case EmergencyType.POLICE:
                {
                    type = (int)GetRandomPoliceVehicle();
                    break;
                }
        }

        Vehicle vehicle = null;
        Ped Driver = null;

        foreach (Vehicle veh in World.GetNearbyVehicles(PlayerPed().Position, 30))
        {
            if (veh.Model.Hash == type && CanWeUse(veh.GetPedOnSeat(VehicleSeat.Driver)) && !veh.GetPedOnSeat(VehicleSeat.Driver).IsPersistent && veh.GetPedOnSeat(VehicleSeat.Driver).IsAlive && !veh.GetPedOnSeat(VehicleSeat.Driver).IsInCombat)
            {
                vehicle = veh;
                Driver = veh.GetPedOnSeat(VehicleSeat.Driver);
            }
        }
        if (!CanWeUse(vehicle))
        {
            Vector3 pos = GenerateSpawnPos(Game.Player.Character.Position.Around(100), Nodetype.Road, false);
            int patience = 0;
            while(patience<50 && (pos==Vector3.Zero || WouldPlayerNoticeChangesHere(pos)))
            {
                patience++;
                GenerateSpawnPos(Game.Player.Character.Position.Around(100), Nodetype.Road, false);
            }
            vehicle = World.CreateVehicle(type, pos, 0);
        }
        if (!CanWeUse(Driver))
        {
            switch (E)
            {
                case EmergencyType.POLICE:
                    {
                        Driver = World.CreatePed(PedHash.Cop01SFY, vehicle.Position, 0);
                        if (CanWeUse(Driver))
                        {
                            Driver.SetIntoVehicle(vehicle, VehicleSeat.Driver);
                        }
                        else
                        {
                            Driver = Function.Call<Ped>(Hash.CREATE_RANDOM_PED_AS_DRIVER, vehicle, true);
                            List<Entity> peds = new List<Entity>();

                            int seats = 1;
                            for (int i = 0; i < seats; i++)
                            {
                                Ped p = World.CreatePed(PedHash.Cop01SMY, vehicle.Position.Around(5));
                                peds.Add(p);
                                p.IsPersistent = false;
                            }
                        }
                        break;
                    }
                case EmergencyType.FIRETRUCK:
                    {
                        Driver = Function.Call<Ped>(Hash.CREATE_RANDOM_PED_AS_DRIVER, vehicle, true);
                        List<Ped> peds = new List<Ped>();

                        int seats = vehicle.PassengerSeats;
                        for (int i = 1; i < seats; i++)
                        {
                            Ped p = World.CreatePed(PedHash.Fireman01SMY, vehicle.Position.Around(5));
                            peds.Add(p);
                            p.IsPersistent = false;
                        }
                        SetPedsIntoVehicle(peds, vehicle);
                        break;
                    }
                case EmergencyType.AMBULANCE:
                    {
                        Driver = Function.Call<Ped>(Hash.CREATE_RANDOM_PED_AS_DRIVER, vehicle, true);
                        List<Ped> peds = new List<Ped>();

                        int seats = vehicle.PassengerSeats;
                        for (int i = 1; i < seats; i++)
                        {
                            Ped p = World.CreatePed(PedHash.Paramedic01SMM, vehicle.Position.Around(5));
                            peds.Add(p);
                            p.IsPersistent = false;
                        }
                        SetPedsIntoVehicle(peds, vehicle);
                        break;
                    }
            }
        }
        vehicle.Heading = Function.Call<float>(GTA.Native.Hash.GET_ANGLE_BETWEEN_2D_VECTORS, vehicle.Position.X, vehicle.Position.Y, Game.Player.Character.Position.X, Game.Player.Character.Position.Y);
        MoveEntitytoNearestRoad(vehicle,true,false);
        PreparePed(Driver, false);
        vehicle.SirenActive = true;


        Function.Call(GTA.Native.Hash.TASK_VEHICLE_DRIVE_WANDER, Driver, vehicle, 30f, (4 + 16 + 32 + 262144));
        Script.Wait(200);
        Function.Call(Hash.SET_VEHICLE_FORWARD_SPEED, vehicle, 10f);

        if (DebugBlips)
        {
            vehicle.AddBlip();
            vehicle.CurrentBlip.Color = BlipColor.Blue;
            vehicle.CurrentBlip.IsFlashing = true;
            vehicle.CurrentBlip.Scale = 0.7f;
            vehicle.CurrentBlip.IsShortRange = true;
            vehicle.CurrentBlip.Name = "Rushing " + vehicle.FriendlyName;
        }
        Driver.IsPersistent = false;
        vehicle.IsPersistent = false;
        SpawnerEventCooldownTime = Game.GameTime + 30000;
            BlacklistedEvents.Add(EventType.EmergencyRushing);
        
    }


    void PreparePed(Ped ped, bool BlockEvents)
    {
        ped.IsPersistent = true;
        ped.AlwaysKeepTask = true;
        ped.BlockPermanentEvents = true;
        Function.Call(GTA.Native.Hash.SET_DRIVER_ABILITY, ped, 100f);
        Function.Call(GTA.Native.Hash.SET_PED_COMBAT_ATTRIBUTES, ped, 46, true);
        //ped.Weapons.Give(WeaponHash.Bat, -1, false, true);
    }



    void SetPedsIntoVehicle(List<Ped> Squad, Vehicle Vehicle)
    {

        if (Squad.Count == 0) return;
        int max_seats = Function.Call<int>(GTA.Native.Hash.GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS, Vehicle);
        for (int i = -1; i < max_seats; i++)
        {
            if (i >= Squad.Count - 1)
            {
                break;
            }
            for (int s = -2; s < 20; s++)
            {
                if (Function.Call<bool>(Hash.IS_VEHICLE_SEAT_FREE, Vehicle, s) && (CanWeUse(Squad[i+1])))
                {
                    Function.Call<bool>(Hash.TASK_ENTER_VEHICLE, Squad[i+1], Vehicle, 10000, s, 2.0, 16, 0);
                    break;
                }
            }

        }
    }
    bool DoesVehicleHavePassengers(Vehicle Vehicle)
    {
        int max_seats = Function.Call<int>(GTA.Native.Hash.GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS, Vehicle);
        for (int i = 0; i < max_seats; i++)
        {
            if (!Function.Call<bool>(GTA.Native.Hash.IS_VEHICLE_SEAT_FREE, Vehicle, i)) return true;
        }
        return false;
    }

    string GetZoneName(Vector3 pos)
    {
        return Function.Call<string>(GTA.Native.Hash.GET_NAME_OF_ZONE, pos.X, pos.Y, pos.Z);
    }


    void LoadSettings()
    {
        ScriptSettings config = ScriptSettings.Load(@"scripts\LivelyWorld.ini");

        AccidentEventProb = config.GetValue<int>("OPTIONS", "AccidentEventBaseProb", 20);
        CriminalEventProb = config.GetValue<int>("OPTIONS", "CriminalEventBaseProb", 10);
        //BlackistedImportantEventsCooldown = config.GetValue<int>("OPTIONS", "ImportantEventsCooldown", 1);

        EventCooldown= config.GetValue<int>("OPTIONS", "EventCooldown", 60)*1000;
        EventFrecuency = config.GetValue<int>("OPTIONS", "EventFrecuency", 50);


        InteractionCooldown = config.GetValue<int>("OPTIONS", "InteractionCooldown", 20) * 1000;
        InteractionFrecuency= config.GetValue<int>("OPTIONS", "InteractionFrecuency", 50);

        InteractionRange = config.GetValue<float>("OPTIONS", "InteractionRange", 200f);

        VehicleReplacer = config.GetValue<bool>("OPTIONS", "TrafficReplacer", true);
        TrafficInjector = config.GetValue<bool>("OPTIONS", "TrafficInjector", true);

        
        TruckRespray = config.GetValue<bool>("OPTIONS", "TruckRespray", true);


        Debug = config.GetValue<bool>("OPTIONS", "Debugmode", false);
        DebugBlips = config.GetValue<bool>("OPTIONS", "DebugBlips", false);
        DebugOutput = config.GetValue<bool>("OPTIONS", "DebugOutput", false);


        //XML
        string ConfigFile = @"scripts\\LivelyWorld.xml";

        XmlDocument document = new XmlDocument();
        document.Load(ConfigFile);
        int pat = 0;
        while (document == null && pat < 500)
        {
            document.Load(ConfigFile);
            Script.Wait(0);
        }

        if (document == null) UI.Notify("~o~LivelyWorld couldn't find the xml file.");
        XmlElement root = document.DocumentElement;
        if (Debug) AddNotification("CHAR_SOCIAL_CLUB", "~b~" + ScriptName + " " + ScriptVer, "LOADING", "Loading settings...");
        if (Debug) AddNotification("", "", "", "Replacers:");
        int Replaced = 0;
        foreach (XmlElement e in root.SelectNodes("//Replacer/model"))
        {
            Model source = e.GetAttribute("source");
            Model target = e.GetAttribute("target");
            if ((source.IsValid || source == "") && target.IsValid)
            {
                Replaced++;
                if (source.IsValid) MonitoredModels.Add(source);
                if (Debug) AddNotification("", "", "","Replacer: "+ e.GetAttribute("source") + " > " + e.GetAttribute("target"));
                ReplacersList.Add(new Replacer(e.GetAttribute("source"), e.GetAttribute("target"), e.GetAttribute("tuned") == "true", e.GetAttribute("timeframe"), e.GetAttribute("zone"), e.GetAttribute("source") + " to " + e.GetAttribute("target") + " - " + e.GetAttribute("timeframe")));
            }
        }

        int Spawned=0;
        foreach (XmlElement e in root.SelectNodes("//Spawner/Traffic/*"))
        {
            Model source = e.GetAttribute("source");
            if ((source.IsValid))
            {
                TerrainType terrain = TerrainType.Road;

                if (e.GetAttribute("terrain") == "air") terrain = TerrainType.Air;
                if (e.GetAttribute("terrain") == "water") terrain = TerrainType.Water;
                if (e.GetAttribute("terrain") == "offroad") terrain = TerrainType.Offroad;
                int cooldown = 3;
                int.TryParse(e.GetAttribute("frecuency"), out cooldown);

                if (cooldown == -1) cooldown = RandomInt(5, 30);

                int prob = 50;
                int.TryParse(e.GetAttribute("probability"), out prob);

                if (prob == -1) prob = RandomInt(20, 80);

                Spawned++;
                if(Debug) AddNotification("", "", "", "Spawner: "+e.GetAttribute("source") + " > " + e.GetAttribute("target")); // if (Debug)
                TrafficSpawnerList.Add(new TrafficSpawner(e.GetAttribute("source"), e.GetAttribute("timeframe"), e.GetAttribute("zone"), terrain, cooldown, prob));
            }
        }
        int Customs = 0;
        string text = "";
        foreach (XmlElement e in root.SelectNodes("//Bennys/model"))
        {
            Model car = e.GetAttribute("source");
            if (car.IsValid)
            {
                Customs++;
                Bennys.Add(e.GetAttribute("source"));
                text += e.GetAttribute("source") + ", ";
            }
        }
        if (Debug) AddNotification("", "", "", "Benny's: " + text);

        int Racers = 0;
        text = "";
        foreach (XmlElement e in root.SelectNodes("//Racers/model"))
        {
            Model car = e.GetAttribute("source");
            if (car.IsValid)
            {
                Racecars.Add(e.GetAttribute("source"));
                text += e.GetAttribute("source") + ", ";
                Racers++;
            }
        }
        if (Debug) AddNotification("", "", "", "Racers:" + text);


        //Disabled events
        text = "";
        foreach (XmlElement e in root.SelectNodes("//DisabledEvents/*"))
        {
            Array events;
            events = Enum.GetValues(typeof(EventType));

            foreach(var ev in events)
            {
                if (e.InnerText == ev.ToString())
                {
                    DisabledEvents.Add((EventType)ev);
                    text += ev.ToString()+", ";
                }
            }
        }

        Notify("CHAR_SOCIAL_CLUB", "~b~" + ScriptName,"Loaded Info",Spawned + " vehicle spawners created.~n~" + Replaced + " vehicles injected into traffic.");
        Notify("", "", "", Racers + " Racers detected.~n~" + Customs + " Benny's vehicles detected.");

        if (DisabledEvents.Count > 0) AddNotification("", "", "", "Disabled events:" + text);

        if (DebugOutput) File.AppendAllText(@"scripts\LivelyWorldDebug.txt", "\n" + DateTime.Now + " - Settings loaded.");

    }


    public static bool IsPlayerNearWater(float range)
    {
        if (IsInNamedArea(Game.Player.Character, "oceana")) return true;
        if (GenerateSpawnPos(Game.Player.Character.Position, Nodetype.Water, false).DistanceTo(Game.Player.Character.Position) < range) return true;

        return false;
    }
    public enum Nodetype { AnyRoad, Road, Offroad, Water }
    public static Vector3 GenerateSpawnPos(Vector3 desiredPos, Nodetype roadtype, bool sidewalk)
    {

        Vector3 finalpos = Vector3.Zero;
        bool ForceOffroad = false;


        OutputArgument outArgA = new OutputArgument();
        int NodeNumber = 1;
        int type = 0;

        if (roadtype == Nodetype.AnyRoad) type = 1;
        if (roadtype == Nodetype.Road) type = 0;
        if (roadtype == Nodetype.Offroad) { type = 1; ForceOffroad = true; }
        if (roadtype == Nodetype.Water) type = 3;


        int NodeID = Function.Call<int>(Hash.GET_NTH_CLOSEST_VEHICLE_NODE_ID, desiredPos.X, desiredPos.Y, desiredPos.Z, NodeNumber, type, 300f, 300f);
        if (ForceOffroad)
        {
            while (!Function.Call<bool>(Hash._GET_IS_SLOW_ROAD_FLAG, NodeID) && NodeNumber < 500)
            {
                Script.Wait(1);
                NodeNumber++;
                Vector3 v = desiredPos.Around(NodeNumber);
                NodeID = Function.Call<int>(Hash.GET_NTH_CLOSEST_VEHICLE_NODE_ID, v.X, v.Y, v.Z, NodeNumber, type, 300f, 300f);
            }
        }
        Function.Call(Hash.GET_VEHICLE_NODE_POSITION, NodeID, outArgA);
        finalpos = outArgA.GetResult<Vector3>();

        if (sidewalk) finalpos = World.GetNextPositionOnSidewalk(finalpos);
        //UI.Notify("Final:" +NodeNumber.ToString());
        return finalpos;
    }
    public static string GetMapAreaAtCoords(Vector3 pos)
    {
        int MapArea;
        MapArea = Function.Call<int>(Hash.GET_HASH_OF_MAP_AREA_AT_COORDS, pos.X, pos.Y, pos.Z);
        if (MapArea == Game.GenerateHash("city")) return "city";
        if (MapArea == Game.GenerateHash("countryside")) return "countryside";
        return MapArea.ToString();
    }


    public static List<String> MessageQueue = new List<String>();
    public static int MessageQueueInterval = 8000;
    public static int MessageQueueReferenceTime = 0;
    public static void HandleMessages()
    {
        if (MessageQueue.Count > 0)
        {
            DisplayHelpTextThisFrame(MessageQueue[0]);
        }
        else
        {
            MessageQueueReferenceTime = Game.GameTime;
        }

        if (Game.GameTime > MessageQueueReferenceTime + MessageQueueInterval)
        {
            if (MessageQueue.Count > 0)
            {
                MessageQueue.RemoveAt(0);
            }
            MessageQueueReferenceTime = Game.GameTime;
        }
    }
    public static void AddQueuedHelpText(string text)
    {
        if (!MessageQueue.Contains(text)) MessageQueue.Add(text);
    }

    public static void ClearAllHelpText(string text)
    {
        MessageQueue.Clear();
    }


    public static List<String> ConversationQueueText = new List<String>();
    public static int ConversationQueueInterval = 8000;
    public static int ConversationQueueReferenceTime = 0;
    public static void HandleConversation()
    {
        if (ConversationQueueText.Count>0 && Game.GameTime > ConversationQueueReferenceTime)
        {
            int Moretime = ((int)(ConversationQueueText[0].Length * 0.1f) * 1000);
            if (Moretime > 8000) Moretime = 8000;
            ConversationQueueReferenceTime = Game.GameTime + Moretime;
            UI.ShowSubtitle(ConversationQueueText[0], Moretime);
            ConversationQueueText.RemoveAt(0);
        }
    }
    public static void AddQueuedConversation(string text)
    {
        if (!ConversationQueueText.Contains(text)) ConversationQueueText.Add(text);
    }

    public static List<String> NotificationQueueText = new List<String>();
    public static List<String> NotificationQueueAvatar = new List<String>();
    public static List<String> NotificationQueueAuthor = new List<String>();
    public static List<String> NotificationQueueTitle = new List<String>();

    public static int NotificationQueueInterval = 8000;
    public static int NotificationQueueReferenceTime = 0;
    public static void HandleNotifications()
    {
        if (Game.GameTime > NotificationQueueReferenceTime)
        {
            if (NotificationQueueAvatar.Count > 0 && NotificationQueueText.Count > 0 && NotificationQueueAuthor.Count > 0 && NotificationQueueTitle.Count > 0)
            {
                int Moretime = ((int)(NotificationQueueText[0].Length * 0.1f) * 1000);
                if (Moretime > 5000) Moretime = 5000;
                NotificationQueueReferenceTime = Game.GameTime + Moretime;
                Notify(NotificationQueueAvatar[0], NotificationQueueAuthor[0], NotificationQueueTitle[0], NotificationQueueText[0]);
                NotificationQueueText.RemoveAt(0);
                NotificationQueueAvatar.RemoveAt(0);
                NotificationQueueAuthor.RemoveAt(0);
                NotificationQueueTitle.RemoveAt(0);
            }
        }
    }

    public static void AddNotification(string avatar, string author, string title, string text)
    {
        NotificationQueueText.Add(text);
        NotificationQueueAvatar.Add(avatar);
        NotificationQueueAuthor.Add(author);
        NotificationQueueTitle.Add(title);
    }
    public static void CleanNotifications()
    {
        NotificationQueueText.Clear();
        NotificationQueueAvatar.Clear();
        NotificationQueueAuthor.Clear();
        NotificationQueueTitle.Clear();
        NotificationQueueReferenceTime = Game.GameTime;
        Function.Call(Hash._REMOVE_NOTIFICATION, CurrentNotification);
    }

    public static int CurrentNotification;
    public static void Notify(string avatar, string author, string title, string message)
    {
        if (avatar != "" && author != "" && title != "")
        {
            Function.Call(Hash._SET_NOTIFICATION_TEXT_ENTRY, "STRING");
            Function.Call(Hash._ADD_TEXT_COMPONENT_STRING, message);
            CurrentNotification = Function.Call<int>(Hash._SET_NOTIFICATION_MESSAGE, avatar, avatar, true, 0, title, author);
        }
        else
        {
            UI.Notify(message);
        }
    }
   public static void DisplayHelpTextThisFrame(string text)
    {
        Function.Call(Hash._SET_TEXT_COMPONENT_FORMAT, "STRING");
        Function.Call(Hash._ADD_TEXT_COMPONENT_STRING, text);
        Function.Call(Hash._0x238FFE5C7B0498A6, 0, 0, 1, -1);
    }
    protected override void Dispose(bool dispose)
    {
        foreach (DrugDeal d in DrugDeals) d.Clear();
        if (CanWeUse(Carjacker)) Carjacker.MarkAsNoLongerNeeded();
        foreach (TaxiEvent t in Taxis) t.Clear();
        foreach (Hunter h in Hunters) h.Clear();
        foreach (TrafficSpawner tr in TrafficSpawnerList) tr.Clear();

        foreach (Entity e in TemporalPersistence)
        {
            e.IsPersistent=false;
        }
        base.Dispose(dispose);

        foreach(Rope r in TrailerRopes) if(r.Exists()) r.Delete();
    }
}